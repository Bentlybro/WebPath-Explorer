/**
 * shared WGSL snippets, included into shader strings via template interpolation.
 *
 * Each snippet defines its function exactly once. A shader module must include any
 * given snippet AT MOST ONCE — WGSL rejects duplicate function definitions, and
 * Chrome/DXC fails silently on the duplicate (no diagnostic). DXC also does not
 * dead-code-eliminate, so include only the snippets a shader actually calls (see
 * `dead-code.test.ts`) — compose the granular `QUAT_*_WGSL` constants rather than
 * pulling in the whole `QUAT_WGSL` bundle when you only need one or two functions.
 */

/** quaternion · quaternion product */
export const QUAT_MUL_WGSL = /* wgsl */ `
fn quatMul(a: vec4f, b: vec4f) -> vec4f {
    return vec4f(
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
    );
}`;

/** conjugate — the inverse rotation for a unit quaternion */
export const QUAT_CONJ_WGSL = /* wgsl */ `
fn quatConj(q: vec4f) -> vec4f {
    return vec4f(-q.x, -q.y, -q.z, q.w);
}`;

/** rotate a vector by a quaternion */
export const QUAT_ROTATE_WGSL = /* wgsl */ `
fn quatRotate(q: vec4f, v: vec3f) -> vec3f {
    let u = q.xyz;
    let t = 2.0 * cross(u, v);
    return v + q.w * t + cross(u, t);
}`;

/** true inverse (divides by |q|²) — use for non-normalized quaternions */
export const QUAT_INV_WGSL = /* wgsl */ `
fn quatInv(q: vec4f) -> vec4f {
    let ls = dot(q, q);
    return vec4f(-q.xyz, q.w) / ls;
}`;

/** all quaternion ops. Prefer the granular constants when you use only some. */
export const QUAT_WGSL = [QUAT_MUL_WGSL, QUAT_CONJ_WGSL, QUAT_ROTATE_WGSL, QUAT_INV_WGSL].join(
    "\n",
);
