// GLB (binary glTF) loader → engine meshes.
//
// Parses a `.glb` ArrayBuffer into one MeshData per primitive (stride-8:
// pos3 | normal3 | uv2), with each primitive's node world-transform baked into
// its vertices and the material's baseColorFactor returned alongside. glTF is
// right-handed Y-up like the engine, so no axis conversion is applied — place
// the model with the consuming entity's Transform.
//
// Register a primitive with `mesh(prim.geometry)` and use `prim.baseColor` for
// the Part color. Not handled: textures/PBR maps, skins, animations, draco.

import type { MeshData } from "../../standard/render";

export interface GltfPrimitive {
    geometry: MeshData;
    /** material baseColorFactor as 0xRRGGBB (white if none) */
    baseColor: number;
    /** embedded baseColorTexture image bytes, if the material has one */
    baseColorImage?: { data: Uint8Array; mimeType: string };
}

const COMPONENT_SIZE: Record<number, number> = { 5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4 };
const TYPE_COUNT: Record<string, number> = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };

type Mat4 = number[]; // column-major

function multiply(a: Mat4, b: Mat4): Mat4 {
    const o = new Array(16).fill(0);
    for (let c = 0; c < 4; c++)
        for (let r = 0; r < 4; r++)
            for (let k = 0; k < 4; k++) o[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k];
    return o;
}

function fromTRS(t?: number[], r?: number[], s?: number[]): Mat4 {
    const tx = t?.[0] ?? 0, ty = t?.[1] ?? 0, tz = t?.[2] ?? 0;
    const x = r?.[0] ?? 0, y = r?.[1] ?? 0, z = r?.[2] ?? 0, w = r?.[3] ?? 1;
    const sx = s?.[0] ?? 1, sy = s?.[1] ?? 1, sz = s?.[2] ?? 1;
    const x2 = x + x, y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2;
    const yy = y * y2, yz = y * z2, zz = z * z2;
    const wx = w * x2, wy = w * y2, wz = w * z2;
    return [
        (1 - (yy + zz)) * sx, (xy + wz) * sx, (xz - wy) * sx, 0,
        (xy - wz) * sy, (1 - (xx + zz)) * sy, (yz + wx) * sy, 0,
        (xz + wy) * sz, (yz - wx) * sz, (1 - (xx + yy)) * sz, 0,
        tx, ty, tz, 1,
    ];
}

interface Gltf {
    accessors: Array<{ bufferView: number; byteOffset?: number; componentType: number; count: number; type: string }>;
    bufferViews: Array<{ byteOffset?: number; byteLength?: number; byteStride?: number }>;
    meshes?: Array<{ primitives: Array<{ attributes: Record<string, number>; indices?: number; material?: number }> }>;
    materials?: Array<{ pbrMetallicRoughness?: { baseColorFactor?: number[]; baseColorTexture?: { index: number } } }>;
    textures?: Array<{ source?: number }>;
    images?: Array<{ bufferView?: number; mimeType?: string; uri?: string }>;
    nodes?: Array<{ mesh?: number; children?: number[]; matrix?: number[]; translation?: number[]; rotation?: number[]; scale?: number[] }>;
    scenes?: Array<{ nodes: number[] }>;
    scene?: number;
}

// Extracts the embedded baseColorTexture image bytes for a material, if any.
function materialImage(gltf: Gltf, bin: ArrayBuffer, materialIdx: number | undefined): { data: Uint8Array; mimeType: string } | undefined {
    const texIdx = materialIdx != null ? gltf.materials?.[materialIdx]?.pbrMetallicRoughness?.baseColorTexture?.index : undefined;
    if (texIdx == null) return undefined;
    const src = gltf.textures?.[texIdx]?.source;
    if (src == null) return undefined;
    const img = gltf.images?.[src];
    if (!img || img.bufferView == null) return undefined; // external/data URIs unsupported
    const bv = gltf.bufferViews[img.bufferView];
    const data = new Uint8Array(bin, bv.byteOffset ?? 0, bv.byteLength ?? 0).slice();
    return { data, mimeType: img.mimeType ?? "image/png" };
}

function readAccessor(gltf: Gltf, bin: ArrayBuffer, idx: number): Float32Array {
    const acc = gltf.accessors[idx];
    const bv = gltf.bufferViews[acc.bufferView];
    const compSize = COMPONENT_SIZE[acc.componentType];
    const numC = TYPE_COUNT[acc.type];
    const base = (bv.byteOffset ?? 0) + (acc.byteOffset ?? 0);
    const stride = bv.byteStride ?? compSize * numC;
    const out = new Float32Array(acc.count * numC);
    const dv = new DataView(bin);
    for (let i = 0; i < acc.count; i++) {
        const o = base + i * stride;
        for (let c = 0; c < numC; c++) {
            const off = o + c * compSize;
            switch (acc.componentType) {
                case 5126: out[i * numC + c] = dv.getFloat32(off, true); break;
                case 5125: out[i * numC + c] = dv.getUint32(off, true); break;
                case 5123: out[i * numC + c] = dv.getUint16(off, true); break;
                case 5122: out[i * numC + c] = dv.getInt16(off, true); break;
                case 5121: out[i * numC + c] = dv.getUint8(off); break;
                case 5120: out[i * numC + c] = dv.getInt8(off); break;
            }
        }
    }
    return out;
}

function materialColor(gltf: Gltf, materialIdx: number | undefined): number {
    const f = materialIdx != null ? gltf.materials?.[materialIdx]?.pbrMetallicRoughness?.baseColorFactor : undefined;
    if (!f) return 0xffffff;
    const ch = (v: number) => Math.round(Math.max(0, Math.min(1, v)) * 255);
    return (ch(f[0] ?? 1) << 16) | (ch(f[1] ?? 1) << 8) | ch(f[2] ?? 1);
}

/**
 * parses a GLB ArrayBuffer into one mesh per primitive, with node transforms
 * baked in and material base colors alongside
 * @example
 * for (const p of parseGlb(buffer)) {
 *   const id = mesh(p.geometry);
 *   const e = state.addEntity();
 *   state.addComponent(e, Part); Part.shape[e] = Shape.Mesh; Part.color[e] = p.baseColor;
 *   state.addComponent(e, Mesh); Mesh.geometry[e] = id;
 * }
 */
export function parseGlb(buffer: ArrayBuffer): GltfPrimitive[] {
    const dv = new DataView(buffer);
    if (dv.getUint32(0, true) !== 0x46546c67) throw new Error("not a GLB file");
    let off = 12;
    let gltf: Gltf | null = null;
    let bin: ArrayBuffer | null = null;
    while (off + 8 <= dv.byteLength) {
        const len = dv.getUint32(off, true);
        const type = dv.getUint32(off + 4, true);
        off += 8;
        if (type === 0x4e4f534a) gltf = JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, off, len)));
        else if (type === 0x004e4942) bin = buffer.slice(off, off + len);
        off += len;
    }
    if (!gltf || !bin) throw new Error("GLB missing JSON or BIN chunk");
    if (!gltf.meshes || !gltf.nodes) return [];

    const out: GltfPrimitive[] = [];
    const sceneNodes = gltf.scenes?.[gltf.scene ?? 0]?.nodes ?? gltf.nodes.map((_, i) => i);

    const visit = (nodeIdx: number, parent: Mat4) => {
        const node = gltf!.nodes![nodeIdx];
        const local = node.matrix ? (node.matrix as Mat4) : fromTRS(node.translation, node.rotation, node.scale);
        const world = multiply(parent, local);
        if (node.mesh != null) {
            for (const prim of gltf!.meshes![node.mesh].primitives) {
                const posIdx = prim.attributes.POSITION;
                if (posIdx == null) continue;
                const pos = readAccessor(gltf!, bin!, posIdx);
                const vCount = pos.length / 3;
                if (vCount > 65535) {
                    console.warn(`[gltf] primitive has ${vCount} verts (>65535) — skipping`);
                    continue;
                }
                const nrm = prim.attributes.NORMAL != null ? readAccessor(gltf!, bin!, prim.attributes.NORMAL) : null;
                const uv = prim.attributes.TEXCOORD_0 != null ? readAccessor(gltf!, bin!, prim.attributes.TEXCOORD_0) : null;
                const vertices = new Float32Array(vCount * 8);
                for (let i = 0; i < vCount; i++) {
                    const x = pos[i * 3], y = pos[i * 3 + 1], z = pos[i * 3 + 2];
                    vertices[i * 8] = world[0] * x + world[4] * y + world[8] * z + world[12];
                    vertices[i * 8 + 1] = world[1] * x + world[5] * y + world[9] * z + world[13];
                    vertices[i * 8 + 2] = world[2] * x + world[6] * y + world[10] * z + world[14];
                    if (nrm) {
                        let nx = world[0] * nrm[i * 3] + world[4] * nrm[i * 3 + 1] + world[8] * nrm[i * 3 + 2];
                        let ny = world[1] * nrm[i * 3] + world[5] * nrm[i * 3 + 1] + world[9] * nrm[i * 3 + 2];
                        let nz = world[2] * nrm[i * 3] + world[6] * nrm[i * 3 + 1] + world[10] * nrm[i * 3 + 2];
                        const l = Math.hypot(nx, ny, nz) || 1;
                        nx /= l; ny /= l; nz /= l;
                        vertices[i * 8 + 3] = nx; vertices[i * 8 + 4] = ny; vertices[i * 8 + 5] = nz;
                    } else {
                        vertices[i * 8 + 4] = 1;
                    }
                    if (uv) { vertices[i * 8 + 6] = uv[i * 2]; vertices[i * 8 + 7] = uv[i * 2 + 1]; }
                }
                let indices: Uint16Array;
                if (prim.indices != null) {
                    const idx = readAccessor(gltf!, bin!, prim.indices);
                    indices = new Uint16Array(idx.length);
                    for (let i = 0; i < idx.length; i++) indices[i] = idx[i];
                } else {
                    indices = new Uint16Array(vCount);
                    for (let i = 0; i < vCount; i++) indices[i] = i;
                }
                out.push({
                    geometry: { vertices, indices, vertexCount: vCount, indexCount: indices.length } as MeshData,
                    baseColor: materialColor(gltf!, prim.material),
                    baseColorImage: materialImage(gltf!, bin!, prim.material),
                });
            }
        }
        for (const c of node.children ?? []) visit(c, world);
    };
    for (const n of sceneNodes) visit(n, [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
    return out;
}
