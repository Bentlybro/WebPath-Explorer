import {
    traits,
    resource,
    pair,
    ChildOf,
    onRemove,
    type State,
    type System,
    type Plugin,
} from "../../engine";
import { clamp, lookAt } from "../../engine/utils";
import { Views } from "../../standard/viewport";
import { Transform } from "../../standard/transforms";
import { Inputs, InputPlugin } from "../../standard/input";
import { Character } from "../../standard/physics";
import { Camera, Part } from "../../standard/render";

/**
 * Third-person (and toggleable first-person) camera + character driver — the gameplay
 * counterpart to the engine's `Player`. Drives a `Character` (physics-resolved movement),
 * pointer-locked mouselook, camera-relative WASD. Press the toggle key (default `KeyV`)
 * to switch between a follow boom and an eye-height first-person view.
 *
 * The camera (a child entity) is damped toward the character with frame-rate-independent
 * exponential smoothing. This decouples it from the GPU character's CPU-readback transform
 * (which arrives 1–2 frames late and irregularly) so the follow stays smooth while the
 * capsule itself renders from the GPU-interpolated matrices.
 *
 * ```xml
 * <a third-person character body="mass: 0" part="shape: capsule" transform>
 *   <a camera viewport transform />
 * </a>
 * ```
 */
export const ThirdPerson = {
    yaw: [] as number[],
    pitch: [] as number[],
    /** boom length in third-person */
    distance: [] as number[],
    /** pivot height above the character origin (third-person look-at point) */
    height: [] as number[],
    /** camera height above the character origin in first-person */
    eyeHeight: [] as number[],
    sprint: [] as number[],
    sensitivity: [] as number[],
    minPitch: [] as number[],
    maxPitch: [] as number[],
    jumpBuffer: [] as number[],
    /** follow stiffness — higher snaps tighter, lower trails more (units: 1/s) */
    smoothing: [] as number[],
    /** 1 = first-person eye view, 0 = third-person boom */
    firstPerson: [] as number[],
};

traits(ThirdPerson, {
    requires: [Transform],
    defaults: () => ({
        yaw: 0,
        pitch: 0.4,
        distance: 8,
        height: 1.2,
        eyeHeight: 0.7,
        sprint: 1.5,
        sensitivity: 1.5,
        minPitch: -1.2,
        maxPitch: 1.35,
        jumpBuffer: 0.1,
        smoothing: 16,
        firstPerson: 0,
    }),
});

/** key that toggles between first- and third-person */
const TOGGLE_KEY = "KeyV";

interface PointerLock {
    canvas: HTMLCanvasElement;
    locked: boolean;
    deltaX: number;
    deltaY: number;
    onClick: () => void;
    onChange: () => void;
    onMove: (e: MouseEvent) => void;
}

const PointerLock = resource<PointerLock>("third-person-pointer-lock");

const cameras = new Map<number, number>();
/** exponentially-smoothed follow position per character */
const smoothed = new Map<number, Float64Array>();

function findCamera(state: State, eid: number): number {
    let cam = cameras.get(eid);
    if (cam !== undefined) return cam;
    for (const child of state.query([pair(ChildOf.relation, eid), Camera])) {
        cam = child;
        break;
    }
    if (cam === undefined) {
        console.warn(`ThirdPerson entity ${eid} has no Camera child.`);
        return -1;
    }
    cameras.set(eid, cam);
    return cam;
}

/** attach pointer-lock listeners once a view (canvas) exists; safe to call every frame */
function ensurePointerLock(state: State): PointerLock | undefined {
    const existing = PointerLock.from(state);
    if (existing) return existing;

    const views = Views.from(state);
    const canvas = views && views.size > 0 ? views.values().next().value?.element : undefined;
    if (!canvas) return undefined;

    const pl: PointerLock = {
        canvas,
        locked: false,
        deltaX: 0,
        deltaY: 0,
        onClick: () => {
            canvas.requestPointerLock().catch(() => {});
        },
        onChange: () => {
            pl.locked = document.pointerLockElement === canvas;
        },
        onMove: (e: MouseEvent) => {
            if (pl.locked) {
                pl.deltaX += e.movementX;
                pl.deltaY += e.movementY;
            }
        },
    };
    canvas.addEventListener("click", pl.onClick);
    document.addEventListener("pointerlockchange", pl.onChange);
    document.addEventListener("mousemove", pl.onMove);
    state.setResource(PointerLock, pl);

    state.observe(onRemove(ThirdPerson), (eid) => {
        cameras.delete(eid);
        smoothed.delete(eid);
    });
    return pl;
}

const ThirdPersonSystem: System = {
    group: "simulation",

    update(state: State) {
        const input = Inputs.from(state);
        if (!input) return;
        const pl = ensurePointerLock(state);
        if (!pl) return;
        const dt = state.time.deltaTime;

        for (const eid of state.query([ThirdPerson, Character, Transform])) {
            // Mouselook (pointer-locked → infinite, wraps freely).
            if (pl.locked) {
                const scale = ThirdPerson.sensitivity[eid] / pl.canvas.clientHeight;
                ThirdPerson.yaw[eid] -= pl.deltaX * scale;
                ThirdPerson.pitch[eid] = clamp(
                    ThirdPerson.pitch[eid] + pl.deltaY * scale,
                    ThirdPerson.minPitch[eid],
                    ThirdPerson.maxPitch[eid],
                );
            }

            // Toggle first/third person.
            if (input.isKeyPressed(TOGGLE_KEY)) {
                const fp = ThirdPerson.firstPerson[eid] ? 0 : 1;
                ThirdPerson.firstPerson[eid] = fp;
                Part.opacity[eid] = fp ? 0 : 1; // hide own body in first-person
            }

            const yaw = ThirdPerson.yaw[eid];
            const pitch = ThirdPerson.pitch[eid];
            const cy = Math.cos(yaw);
            const sy = Math.sin(yaw);
            const cp = Math.cos(pitch);
            const sp = Math.sin(pitch);

            // Camera-relative movement (W drives the character forward, away from the camera).
            let lx = 0;
            let lz = 0;
            if (input.isKeyDown("KeyW")) lz -= 1;
            if (input.isKeyDown("KeyS")) lz += 1;
            if (input.isKeyDown("KeyA")) lx -= 1;
            if (input.isKeyDown("KeyD")) lx += 1;
            const len = Math.sqrt(lx * lx + lz * lz);
            if (len > 0) {
                const sprinting = input.isKeyDown("ShiftLeft") || input.isKeyDown("ShiftRight");
                const speed =
                    (Character.speed[eid] * (sprinting ? ThirdPerson.sprint[eid] : 1)) / len;
                Character.moveX[eid] = (lz * sy + lx * cy) * speed;
                Character.moveZ[eid] = (lz * cy - lx * sy) * speed;
            } else {
                Character.moveX[eid] = 0;
                Character.moveZ[eid] = 0;
            }
            Character.jump[eid] =
                input.isKeyDown("Space") ||
                input.isKeyPressedWithin("Space", ThirdPerson.jumpBuffer[eid])
                    ? 1
                    : 0;

            const cam = findCamera(state, eid);
            if (cam < 0) continue;

            // Exponential follow smoothing toward the character (frame-rate independent).
            const px = Transform.posX[eid];
            const py = Transform.posY[eid];
            const pz = Transform.posZ[eid];
            let s = smoothed.get(eid);
            if (!s) {
                s = new Float64Array([px, py, pz]);
                smoothed.set(eid, s);
            }
            const k = 1 - Math.exp(-ThirdPerson.smoothing[eid] * dt);
            s[0] += (px - s[0]) * k;
            s[1] += (py - s[1]) * k;
            s[2] += (pz - s[2]) * k;
            // Correction added to the camera's *local* offset so its world position tracks the
            // smoothed point (parent transform later adds back the character's own position).
            const ox = s[0] - px;
            const oy = s[1] - py;
            const oz = s[2] - pz;

            // Direction from the pivot toward the camera (camera sits behind in third-person).
            const dx = cp * sy;
            const dy = sp;
            const dz = cp * cy;

            let eyeX: number;
            let eyeY: number;
            let eyeZ: number;
            let tgtX: number;
            let tgtY: number;
            let tgtZ: number;
            if (ThirdPerson.firstPerson[eid]) {
                const h = ThirdPerson.eyeHeight[eid];
                eyeX = ox;
                eyeY = oy + h;
                eyeZ = oz;
                tgtX = eyeX - dx;
                tgtY = eyeY - dy;
                tgtZ = eyeZ - dz;
            } else {
                const h = ThirdPerson.height[eid];
                const dist = ThirdPerson.distance[eid];
                tgtX = ox;
                tgtY = oy + h;
                tgtZ = oz;
                eyeX = tgtX + dist * dx;
                eyeY = tgtY + dist * dy;
                eyeZ = tgtZ + dist * dz;
            }

            Transform.posX[cam] = eyeX;
            Transform.posY[cam] = eyeY;
            Transform.posZ[cam] = eyeZ;
            const q = lookAt(eyeX, eyeY, eyeZ, tgtX, tgtY, tgtZ);
            Transform.quatX[cam] = q.x;
            Transform.quatY[cam] = q.y;
            Transform.quatZ[cam] = q.z;
            Transform.quatW[cam] = q.w;
        }

        pl.deltaX = 0;
        pl.deltaY = 0;
    },

    dispose(state: State) {
        cameras.clear();
        smoothed.clear();
        const pl = PointerLock.from(state);
        if (!pl) return;
        if (pl.locked) document.exitPointerLock();
        pl.canvas.removeEventListener("click", pl.onClick);
        document.removeEventListener("pointerlockchange", pl.onChange);
        document.removeEventListener("mousemove", pl.onMove);
        state.deleteResource(PointerLock);
    },
};

export const ThirdPersonPlugin: Plugin = {
    name: "ThirdPerson",
    systems: [ThirdPersonSystem],
    components: { ThirdPerson },
    dependencies: [InputPlugin],
};
