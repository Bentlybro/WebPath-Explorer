// Lightweight procedural transform animators: continuous Spin and sinusoidal
// Oscillate. Both drive an entity's Transform each frame and compose with the
// ECS hierarchy (a spinning/moving parent carries its children), so they're a
// general building block for idle motion — rotating pickups, bobbing platforms,
// drifting props, etc.

import { traits, type Plugin, type System, type State } from "../../engine";
import { Transform } from "../../standard/transforms";

/**
 * continuous rotation about a (local) axis at `speed` radians/second
 * @example
 * state.addComponent(e, Spin);
 * Spin.axisY[e] = 1; Spin.speed[e] = Math.PI; // half a turn per second about Y
 */
export const Spin = {
    axisX: [] as number[],
    axisY: [] as number[],
    axisZ: [] as number[],
    speed: [] as number[],
};

traits(Spin, {
    requires: [Transform],
    defaults: () => ({ axisX: 0, axisY: 1, axisZ: 0, speed: 1 }),
});

/**
 * sinusoidal oscillation of position about `base` along `axis`:
 * pos = base + axis * amplitude * sin(2π·t/period + phase)
 * @example
 * state.addComponent(e, Oscillate);
 * Oscillate.baseY[e] = Transform.posY[e]; Oscillate.axisY[e] = 1;
 * Oscillate.amplitude[e] = 2; Oscillate.period[e] = 3;
 */
export const Oscillate = {
    baseX: [] as number[],
    baseY: [] as number[],
    baseZ: [] as number[],
    axisX: [] as number[],
    axisY: [] as number[],
    axisZ: [] as number[],
    amplitude: [] as number[],
    period: [] as number[],
    phase: [] as number[],
};

traits(Oscillate, {
    requires: [Transform],
    defaults: () => ({
        baseX: 0, baseY: 0, baseZ: 0,
        axisX: 0, axisY: 1, axisZ: 0,
        amplitude: 1, period: 2, phase: 0,
    }),
});

const SpinSystem: System = {
    group: "simulation",
    annotations: { mode: "always" }, // run in edit mode too (only writes Transform)
    update(state: State) {
        const dt = state.time.deltaTime;
        if (dt <= 0) return;
        for (const eid of state.query([Spin, Transform])) {
            const ax = Spin.axisX[eid], ay = Spin.axisY[eid], az = Spin.axisZ[eid];
            const len = Math.hypot(ax, ay, az);
            if (len < 1e-8) continue;
            const half = (Spin.speed[eid] * dt) / 2;
            const s = Math.sin(half) / len;
            const dx = ax * s, dy = ay * s, dz = az * s, dw = Math.cos(half);
            const qx = Transform.quatX[eid], qy = Transform.quatY[eid], qz = Transform.quatZ[eid], qw = Transform.quatW[eid];
            // q = q ⊗ delta — spin about the entity's OWN (local) axis, like
            // three.js object.rotation, so a rotated entity still spins correctly.
            let nx = qw * dx + qx * dw + qy * dz - qz * dy;
            let ny = qw * dy - qx * dz + qy * dw + qz * dx;
            let nz = qw * dz + qx * dy - qy * dx + qz * dw;
            let nw = qw * dw - qx * dx - qy * dy - qz * dz;
            const inv = 1 / (Math.hypot(nx, ny, nz, nw) || 1);
            nx *= inv; ny *= inv; nz *= inv; nw *= inv;
            Transform.quatX[eid] = nx; Transform.quatY[eid] = ny; Transform.quatZ[eid] = nz; Transform.quatW[eid] = nw;
        }
    },
};

const OscillateSystem: System = {
    group: "simulation",
    annotations: { mode: "always" }, // run in edit mode too (only writes Transform)
    update(state: State) {
        const t = state.time.elapsed;
        for (const eid of state.query([Oscillate, Transform])) {
            const period = Oscillate.period[eid] || 1;
            const off = Oscillate.amplitude[eid] * Math.sin((2 * Math.PI * t) / period + Oscillate.phase[eid]);
            Transform.posX[eid] = Oscillate.baseX[eid] + Oscillate.axisX[eid] * off;
            Transform.posY[eid] = Oscillate.baseY[eid] + Oscillate.axisY[eid] * off;
            Transform.posZ[eid] = Oscillate.baseZ[eid] + Oscillate.axisZ[eid] * off;
        }
    },
};

export const AnimatePlugin: Plugin = {
    name: "Animate",
    systems: [SpinSystem, OscillateSystem],
    components: { Spin, Oscillate },
};
