import { type State, Shape } from "../../engine";
import { Transform } from "../../standard/transforms";
import { Part } from "../../standard/render";

/**
 * Bridge SpacetimeDB tables onto Shallot ECS entities. The SpacetimeDB row is the one
 * source of truth; the ECS entity is the derived view. Row callbacks fire between frames
 * (JS is single-threaded; `state.step()` is synchronous), so spawning/despawning entities
 * directly in callbacks never races with a system iterating a query.
 */

/** structural view of a generated table handle (`conn.db.<table>`) */
export interface NetTable<Row> {
    onInsert(cb: (ctx: unknown, row: Row) => void): void;
    onDelete(cb: (ctx: unknown, row: Row) => void): void;
    onUpdate(cb: (ctx: unknown, oldRow: Row, newRow: Row) => void): void;
    iter(): Iterable<Row>;
}

export interface SyncTableOptions<Row> {
    table: NetTable<Row>;
    /** stable identity per row (e.g. primary key) */
    key: (row: Row) => string | number;
    /** rows to ignore entirely (e.g. the local player, which the game owns) */
    skip?: (row: Row) => boolean;
    /** create the ECS entity for a row, returns its eid */
    spawn: (state: State, row: Row) => number;
    /** write a row's data onto its entity (called on insert and every update) */
    apply: (state: State, eid: number, row: Row) => void;
    /** tear down an entity (default: `state.removeEntity`) */
    despawn?: (state: State, eid: number, row: Row) => void;
}

/**
 * keep an ECS entity per table row, spawning/despawning as rows insert/delete and
 * re-applying on update. Spawns any rows already present when called. Returns a cleanup
 * that removes all spawned entities.
 */
export function syncTable<Row>(state: State, opts: SyncTableOptions<Row>): () => void {
    const map = new Map<string | number, number>();
    const skip = opts.skip ?? (() => false);

    const insert = (row: Row): void => {
        if (skip(row)) return;
        const k = opts.key(row);
        let eid = map.get(k);
        if (eid === undefined) {
            eid = opts.spawn(state, row);
            map.set(k, eid);
        }
        opts.apply(state, eid, row);
    };

    const update = (row: Row): void => {
        if (skip(row)) return;
        const eid = map.get(opts.key(row));
        if (eid === undefined) insert(row);
        else opts.apply(state, eid, row);
    };

    const remove = (row: Row): void => {
        const k = opts.key(row);
        const eid = map.get(k);
        if (eid === undefined) return;
        map.delete(k);
        if (opts.despawn) opts.despawn(state, eid, row);
        else state.removeEntity(eid);
    };

    for (const row of opts.table.iter()) insert(row);
    opts.table.onInsert((_ctx, row) => insert(row));
    opts.table.onUpdate((_ctx, _old, row) => update(row));
    opts.table.onDelete((_ctx, row) => remove(row));

    return () => {
        for (const eid of map.values()) state.removeEntity(eid);
        map.clear();
    };
}

/** 7-tuple px, py, pz, qx, qy, qz, qw */
export type NetTransform = [number, number, number, number, number, number, number];

export interface SyncTransformsOptions<Row> {
    table: NetTable<Row>;
    key: (row: Row) => string | number;
    skip?: (row: Row) => boolean;
    /** extract the world transform from a row */
    transform: (row: Row) => NetTransform;
    /**
     * customize the spawned entity (mesh, color, extra components). The entity already
     * has `Transform` + `Part` (default: a unit capsule). Optional.
     */
    create?: (state: State, eid: number, row: Row) => void;
}

/**
 * sync a table of transform-bearing rows onto rendered entities — the common multiplayer
 * case (players, props). Each row becomes a capsule (override via `create`) whose
 * `Transform` tracks the row.
 * @example
 * syncTransforms(state, {
 *     table: conn.db.player,
 *     key: (p) => p.identity.toHexString(),
 *     skip: (p) => p.identity.toHexString() === myIdentity,
 *     transform: (p) => [p.px, p.py, p.pz, p.qx, p.qy, p.qz, p.qw],
 *     create: (s, eid, p) => { Part.color[eid] = p.color; },
 * });
 */
export function syncTransforms<Row>(state: State, opts: SyncTransformsOptions<Row>): () => void {
    return syncTable(state, {
        table: opts.table,
        key: opts.key,
        skip: opts.skip,
        spawn(s, row) {
            const eid = s.addEntity();
            s.addComponent(eid, Transform);
            s.addComponent(eid, Part);
            Part.shape[eid] = Shape.Capsule;
            opts.create?.(s, eid, row);
            return eid;
        },
        apply(_s, eid, row) {
            const [px, py, pz, qx, qy, qz, qw] = opts.transform(row);
            Transform.posX[eid] = px;
            Transform.posY[eid] = py;
            Transform.posZ[eid] = pz;
            Transform.quatX[eid] = qx;
            Transform.quatY[eid] = qy;
            Transform.quatZ[eid] = qz;
            Transform.quatW[eid] = qw;
        },
    });
}
