export {
    Spacetime,
    SpacetimePlugin,
    connect,
    type SpacetimeState,
    type SpacetimeConnection,
    type SpacetimeBuilder,
    type SpacetimeIdentity,
    type ConnectOptions,
} from "./connection";

export {
    syncTable,
    syncTransforms,
    type NetTable,
    type NetTransform,
    type SyncTableOptions,
    type SyncTransformsOptions,
} from "./sync";
