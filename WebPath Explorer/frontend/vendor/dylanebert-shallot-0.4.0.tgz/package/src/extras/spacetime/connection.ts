import { resource, type Plugin, type State } from "../../engine";

/**
 * SpacetimeDB networking — reusable glue between a generated SpacetimeDB module and
 * Shallot's ECS. The engine carries no dependency on the `spacetimedb` SDK: a game
 * brings the SDK + its generated bindings and passes the typed connection in. This
 * file works against *structural* interfaces so any module's connection fits.
 */

/** structural view of a generated `DbConnection` (the game supplies the real typed one). */
export interface SpacetimeConnection {
    db: unknown;
    reducers: unknown;
    identity?: SpacetimeIdentity;
    isActive: boolean;
    disconnect(): void;
}

export interface SpacetimeIdentity {
    toHexString(): string;
}

/** structural view of `DbConnection.builder()`. */
export interface SpacetimeBuilder<C extends SpacetimeConnection> {
    withUri(uri: string | URL): this;
    withDatabaseName(name: string): this;
    withToken(token?: string): this;
    onConnect(cb: (conn: C, identity: SpacetimeIdentity, token: string) => void): this;
    onConnectError(cb: (ctx: unknown, err: Error) => void): this;
    onDisconnect(cb: (ctx: unknown, err?: Error) => void): this;
    build(): C;
}

/** live connection + resolved identity, stored as a resource once connected */
export interface SpacetimeState<C extends SpacetimeConnection = SpacetimeConnection> {
    conn: C;
    /** this client's stable identity, hex-encoded */
    identity: string;
}

/** resource holding the active SpacetimeDB connection; `Spacetime.from(state)` to read it */
export const Spacetime = resource<SpacetimeState>("spacetime");

export interface ConnectOptions {
    /** server URI, e.g. "https://maincloud.spacetimedb.com" */
    uri: string;
    /** published database name */
    database: string;
    /**
     * localStorage key for persisting the auth token, giving the client a stable
     * identity across reloads. Default `"spacetime-token"`.
     */
    tokenKey?: string;
}

/**
 * connect using a generated `DbConnection.builder()`. Persists the auth token to
 * localStorage so the client keeps a stable identity across reloads, and resolves
 * once the server confirms the connection.
 * @example
 * const { conn, identity } = await connect(DbConnection.builder(), {
 *     uri: "https://maincloud.spacetimedb.com",
 *     database: "shallot-sandbox",
 * });
 */
export function connect<C extends SpacetimeConnection>(
    builder: SpacetimeBuilder<C>,
    options: ConnectOptions,
): Promise<SpacetimeState<C>> {
    const tokenKey = options.tokenKey ?? "spacetime-token";
    const saved =
        typeof localStorage !== "undefined"
            ? (localStorage.getItem(tokenKey) ?? undefined)
            : undefined;

    return new Promise<SpacetimeState<C>>((resolve, reject) => {
        builder
            .withUri(options.uri)
            .withDatabaseName(options.database)
            .withToken(saved)
            .onConnect((conn, identity, token) => {
                try {
                    localStorage?.setItem(tokenKey, token);
                } catch {
                    // localStorage unavailable (e.g. private mode) — connection still works,
                    // the client just gets a fresh identity next reload.
                }
                resolve({ conn, identity: identity.toHexString() });
            })
            .onConnectError((_ctx, err) => reject(err))
            .build();
    });
}

/**
 * tears the SpacetimeDB connection down when the Shallot `State` is disposed. Register it,
 * then store a connected `Spacetime` resource via `connect()` + `state.setResource(Spacetime, ...)`.
 */
export const SpacetimePlugin: Plugin = {
    name: "Spacetime",
    initialize(state: State) {
        state.onDispose(() => {
            Spacetime.from(state)?.conn.disconnect();
        });
    },
};
