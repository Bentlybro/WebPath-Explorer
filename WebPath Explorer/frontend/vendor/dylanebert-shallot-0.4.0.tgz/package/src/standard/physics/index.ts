import {
    resource,
    onAdd,
    onRemove,
    Time,
    capacity,
    write,
    type Plugin,
    type State,
    type System,
} from "../../engine";
import { Transform } from "../transforms";
import { Part, Mesh, Render, RenderPlugin } from "../render";
import { binding, type GBuf, type Binding } from "../compute";
import { PartSizes, PartShapes } from "../render/core";
import {
    Compute,
    ComputePlugin,
    beginComputePass,
    type ComputeNode,
    type ExecutionContext,
} from "../compute";
import { interpolateWGSL } from "./interpolate.wgsl";
import {
    GpuProfile,
    allocSlot,
    resetProfile,
    resolveProfile,
    readProfile,
    drainProfile,
} from "../compute/core";
import {
    maxConstraints,
    CONSTRAINT_BYTES,
    hashCapacity,
    JOINT_BYTES,
    MAX_COLORS,
    COLORING_ROUNDS,
    solverStateSize,
    COUNTERS_SIZE,
    csrHeadsOffset,
    csrOffsetsOffset,
    SS_CONSTRAINT_COUNT,
    SS_USED_COLORS,
    MAX_CONTACTS,
    CONTACT_STRIDE,
    NUM_PAIR_TYPES,
} from "./solver.wgsl";
import { BODY_BYTES } from "./utility.wgsl";
import { rebuildPrefixSum, dispatchPrefixSum, disposePrefixSum } from "../radix";
import { dispatchPhysicsLBVH, disposePhysicsLBVH } from "./lbvh";
import { resolveChanges, packJointData, type JointInput, type SpringJointInput } from "./body";
import { packHullsForGPU, hullRegistry } from "./hull";
import { Shape } from "../../engine";
import type { PhysicsGPU } from "./gpu";
import { createGPU } from "./core/gpu-init";
import { beginPass, beginPassIndirect } from "./core/pass";
import { requestReadback, processReadback } from "./core/readback";
export { readBodies } from "./core/readback";
import {
    Body,
    Force,
    Impulse,
    Velocity,
    BallJoint,
    SpringJoint,
    Character,
    Move,
    BodyData,
} from "./components";
import { Contacts } from "./contact";

export {
    Body,
    Force,
    Impulse,
    Velocity,
    BallJoint,
    SpringJoint,
    Character,
    Move,
} from "./components";
export { contactReader, readContacts, Contacts } from "./contact";
export type { Contact, ContactReader } from "./contact";

export {
    raycast,
    raySphere,
    rayCapsule,
    rayOBB,
    rayTriangle,
    rayMesh,
    generateRay,
    screenToRay,
} from "./raycast";
export type { Hit } from "./raycast";
export { hull, hullRegistry } from "./hull";
export type { ConvexHull, ConvexHullFace } from "./hull";
export { satHullHull, satHullBox, satHullSphere, satHullCapsule, boxToHull } from "./sat";
export type { SatContact, SatBody } from "./sat";

export const Physics = resource<PhysicsGPU>("physics");

function pushChange(gpu: PhysicsGPU, value: number): void {
    if (gpu.pendingChangeCount >= gpu.pendingChanges.length) {
        const next = new Int32Array(gpu.pendingChanges.length * 2);
        next.set(gpu.pendingChanges);
        gpu.pendingChanges = next;
    }
    gpu.pendingChanges[gpu.pendingChangeCount++] = value;
}

const rebuildScratch = new Uint32Array(4);

let eidsScratch = new Uint32Array(capacity());
const packParamsScratch = new Uint32Array(4);
let cachedEidsCapacity = capacity();

function ensureEidsScratch(): void {
    const c = capacity();
    if (c !== cachedEidsCapacity) {
        cachedEidsCapacity = c;
        eidsScratch = new Uint32Array(c);
    }
}

let hullIdsScratch = new Uint32Array(0);

function uploadHullData(gpu: PhysicsGPU): void {
    const packed = packHullsForGPU();
    const dataBytes = packed.data.byteLength;
    if (dataBytes === 0) return;
    if (dataBytes > gpu.hullDataBuffer.buffer.size) {
        gpu.hullDataBuffer.buffer.destroy();
        gpu.hullDataBuffer.buffer = gpu.device.createBuffer({
            label: "physics-hullData",
            size: dataBytes,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });
        gpu.pairBindGroup.invalidate();
    }
    gpu.device.queue.writeBuffer(
        gpu.hullDataBuffer.buffer,
        0,
        packed.data as Uint32Array<ArrayBuffer>,
    );
}

function uploadHullIds(gpu: PhysicsGPU): void {
    const bodyCount = gpu.bodyEids.length;
    if (bodyCount === 0) return;
    if (hullIdsScratch.length < bodyCount) {
        hullIdsScratch = new Uint32Array(bodyCount);
    }
    for (let i = 0; i < bodyCount; i++) {
        const eid = gpu.bodyEids[i];
        if (Part.shape[eid] === Shape.Mesh) {
            const meshId = Mesh.geometry[eid];
            hullIdsScratch[i] = hullRegistry.getByName(String(meshId)) ?? 0;
        } else {
            hullIdsScratch[i] = 0;
        }
    }
    gpu.device.queue.writeBuffer(gpu.hullIdsBuffer.buffer, 0, hullIdsScratch, 0, bodyCount);
}

function syncJoints(state: State, gpu: PhysicsGPU): void {
    const eids = gpu.bodyEids;
    const eidToIndex = new Map<number, number>();
    for (let i = 0; i < eids.length; i++) eidToIndex.set(eids[i], i);

    const ballJoints: JointInput[] = [];
    for (const eid of state.query([BallJoint])) {
        ballJoints.push({
            anchorAX: BallJoint.anchorAX[eid] ?? 0,
            anchorAY: BallJoint.anchorAY[eid] ?? 0,
            anchorAZ: BallJoint.anchorAZ[eid] ?? 0,
            bodyA: BallJoint.bodyA[eid],
            anchorBX: BallJoint.anchorBX[eid] ?? 0,
            anchorBY: BallJoint.anchorBY[eid] ?? 0,
            anchorBZ: BallJoint.anchorBZ[eid] ?? 0,
            bodyB: BallJoint.bodyB[eid],
            stiffness: BallJoint.stiffness[eid] ?? 0,
            fracture: BallJoint.fracture[eid] ?? 0,
        });
    }

    const springJoints: SpringJointInput[] = [];
    for (const eid of state.query([SpringJoint])) {
        springJoints.push({
            anchorAX: SpringJoint.anchorAX[eid] ?? 0,
            anchorAY: SpringJoint.anchorAY[eid] ?? 0,
            anchorAZ: SpringJoint.anchorAZ[eid] ?? 0,
            bodyA: SpringJoint.bodyA[eid],
            anchorBX: SpringJoint.anchorBX[eid] ?? 0,
            anchorBY: SpringJoint.anchorBY[eid] ?? 0,
            anchorBZ: SpringJoint.anchorBZ[eid] ?? 0,
            bodyB: SpringJoint.bodyB[eid],
            stiffness: SpringJoint.stiffness[eid] ?? 0,
            fracture: SpringJoint.fracture[eid] ?? 0,
            restLength: SpringJoint.restLength[eid] ?? 0,
        });
    }

    const count = ballJoints.length + springJoints.length;
    gpu.jointCount = count;
    if (count === 0) return;

    const slot = gpu.jointSlot;
    if (count > slot.capacity) {
        slot.buffer.destroy();
        slot.capacity = count;
        slot.buffer = gpu.device.createBuffer({
            label: "physics-joints",
            size: count * JOINT_BYTES,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });
        gpu.jointsBuffer = slot.buffer;
        gpu.solverBindGroup.invalidate();
        gpu.narrowBindGroup.invalidate();
    }

    const jointData = packJointData(ballJoints, springJoints, eidToIndex);
    gpu.device.queue.writeBuffer(slot.buffer, 0, jointData as Float32Array<ArrayBuffer>);
}

function processBodyChanges(gpu: PhysicsGPU, state: State, encoder: GPUCommandEncoder): void {
    if (gpu.pendingChangeCount === 0 && !gpu.jointsNeedUpload) return;

    const { removeOps, addEids } = resolveChanges(
        gpu.pendingChanges,
        gpu.pendingChangeCount,
        gpu.bodyEids,
        capacity(),
    );
    gpu.pendingChangeCount = 0;
    const addCount = addEids.length;
    const firstNewIndex = gpu.bodyEids.length - addCount;

    const bodyCount = gpu.bodyEids.length;
    const queue = gpu.device.queue;

    if (addCount > 0) {
        const entityCount = state.max + 1;
        ensureEidsScratch();
        write(queue, gpu.sizesBuffer.buffer, 0, PartSizes, entityCount);
        write(queue, gpu.shapesBuffer.buffer, 0, PartShapes, entityCount);
        write(queue, gpu.bodyPropsBuffer.buffer, 0, BodyData, entityCount);
        uploadHullData(gpu);
        uploadHullIds(gpu);
    }

    if (addCount > 0 || removeOps.length > 0) {
        ensureEidsScratch();
        for (let i = 0; i < bodyCount; i++) eidsScratch[i] = gpu.bodyEids[i];
        queue.writeBuffer(gpu.eidsBuffer.buffer, 0, eidsScratch, 0, bodyCount);
        gpu.bodyGeneration++;
    }

    packParamsScratch[0] = bodyCount;
    packParamsScratch[1] = capacity();
    packParamsScratch[2] = firstNewIndex;
    queue.writeBuffer(gpu.packParamsBuffer, 0, packParamsScratch);

    // Apply swap-remove copies BEFORE pack: pack writes new bodies at firstNewIndex onward,
    // which can collide with a removeOp's lastIdx (the slot pack just wrote into would be
    // copied over the swap target, scrambling slot identity).
    for (let i = 0; i < removeOps.length; i++) {
        const { removedIdx, lastIdx } = removeOps[i];
        encoder.copyBufferToBuffer(
            gpu.bodyBuffer.buffer,
            lastIdx * BODY_BYTES,
            gpu.bodyBuffer.buffer,
            removedIdx * BODY_BYTES,
            BODY_BYTES,
        );
        encoder.copyBufferToBuffer(
            gpu.bodyBufferPrev.buffer,
            lastIdx * BODY_BYTES,
            gpu.bodyBufferPrev.buffer,
            removedIdx * BODY_BYTES,
            BODY_BYTES,
        );
    }

    if (addCount > 0) {
        // Pack runs over all bodies: full init for new (i >= offset), shape refresh for
        // existing. Existing bodies' shape-derived fields (halfExtents, moments, radius)
        // would otherwise stay stale when Part.size* changes (e.g., pile ramp arena resize).
        const pass = beginComputePass(encoder);
        pass.setPipeline(gpu.packPipeline);
        pass.setBindGroup(0, gpu.packBindGroup.group);
        pass.dispatchWorkgroups(Math.ceil(bodyCount / 64));
        pass.end();
    }

    if (removeOps.length > 0 || gpu.jointsNeedUpload) {
        syncJoints(state, gpu);
        gpu.jointsNeedUpload = false;
    }
}

function uploadParams(gpu: PhysicsGPU, bodyCount: number): void {
    const view = gpu.paramsView;
    view.setFloat32(0, gpu.params.dt, true);
    view.setFloat32(4, gpu.params.gravity, true);
    view.setUint32(8, gpu.params.iterations, true);
    view.setFloat32(12, gpu.params.alpha, true);
    view.setFloat32(16, gpu.params.betaLin, true);
    view.setFloat32(20, gpu.params.gamma, true);
    view.setUint32(24, bodyCount, true);
    view.setUint32(28, gpu.jointCount, true);
    view.setUint32(32, capacity(), true);
    view.setUint32(36, maxConstraints() / capacity(), true);
    view.setUint32(40, hashCapacity() / capacity(), true);
    view.setFloat32(44, gpu.params.betaAng, true);
    view.setUint32(48, 0, true);
    view.setUint32(52, 0, true);
    view.setUint32(56, 0, true);
    view.setUint32(60, 0, true);
    gpu.device.queue.writeBuffer(gpu.paramsBuffer, 0, gpu.paramsData);
}

let forceScratch = new Float32Array(0);
const forceEidToIndex = new Map<number, number>();
const consumedEids: number[] = [];

function packForces(gpu: PhysicsGPU, state: State): void {
    const bodyCount = gpu.bodyEids.length;
    if (bodyCount === 0) return;

    const eids = gpu.bodyEids;
    const map = forceEidToIndex;
    map.clear();
    for (let i = 0; i < eids.length; i++) map.set(eids[i], i);

    const needed = bodyCount * 8;
    if (forceScratch.length < needed) forceScratch = new Float32Array(needed);
    else forceScratch.fill(0, 0, needed);

    let hasForce = false;
    for (const eid of state.query([Force])) {
        const idx = map.get(eid);
        if (idx === undefined) continue;
        hasForce = true;
        const off = idx * 8;
        forceScratch[off] = Force.forceX[eid];
        forceScratch[off + 1] = Force.forceY[eid];
        forceScratch[off + 2] = Force.forceZ[eid];
        forceScratch[off + 3] = Force.torqueX[eid];
        forceScratch[off + 4] = Force.torqueY[eid];
        forceScratch[off + 5] = Force.torqueZ[eid];
    }

    consumedEids.length = 0;
    const invDt = 1 / gpu.params.dt;
    for (const eid of state.query([Impulse])) {
        const idx = map.get(eid);
        if (idx === undefined) continue;
        hasForce = true;
        const off = idx * 8;
        forceScratch[off] += Impulse.impulseX[eid] * invDt;
        forceScratch[off + 1] += Impulse.impulseY[eid] * invDt;
        forceScratch[off + 2] += Impulse.impulseZ[eid] * invDt;
        forceScratch[off + 3] += Impulse.angularImpulseX[eid] * invDt;
        forceScratch[off + 4] += Impulse.angularImpulseY[eid] * invDt;
        forceScratch[off + 5] += Impulse.angularImpulseZ[eid] * invDt;
        consumedEids.push(eid);
    }
    for (const eid of consumedEids) state.removeComponent(eid, Impulse);

    consumedEids.length = 0;
    for (const eid of state.query([Velocity])) {
        const idx = map.get(eid);
        if (idx === undefined) continue;
        hasForce = true;
        const off = idx * 8;
        forceScratch[off] = Velocity.linearX[eid];
        forceScratch[off + 1] = Velocity.linearY[eid];
        forceScratch[off + 2] = Velocity.linearZ[eid];
        forceScratch[off + 3] = Velocity.angularX[eid];
        forceScratch[off + 4] = Velocity.angularY[eid];
        forceScratch[off + 5] = Velocity.angularZ[eid];
        forceScratch[off + 6] = 1.0;
        consumedEids.push(eid);
    }
    for (const eid of consumedEids) state.removeComponent(eid, Velocity);

    if (!hasForce) return;
    gpu.device.queue.writeBuffer(gpu.forceBuffer.buffer, 0, forceScratch, 0, needed);
}

let moveScratch = new Float32Array(0);

function syncTransforms(gpu: PhysicsGPU, state: State): void {
    if (gpu.bodyEids.length === 0) return;
    const S = capacity();
    const queue = gpu.device.queue;
    const buf = gpu.unpackTransformBuffer.buffer;
    type F32 = Float32Array<ArrayBuffer>;

    queue.writeBuffer(buf, 0, Transform.posX as F32, 0, S);
    queue.writeBuffer(buf, S * 4, Transform.posY as F32, 0, S);
    queue.writeBuffer(buf, 2 * S * 4, Transform.posZ as F32, 0, S);
    queue.writeBuffer(buf, 3 * S * 4, Transform.quatX as F32, 0, S);
    queue.writeBuffer(buf, 4 * S * 4, Transform.quatY as F32, 0, S);
    queue.writeBuffer(buf, 5 * S * 4, Transform.quatZ as F32, 0, S);
    queue.writeBuffer(buf, 6 * S * 4, Transform.quatW as F32, 0, S);

    if (moveScratch.length < S) moveScratch = new Float32Array(S);
    else moveScratch.fill(0);
    for (const eid of gpu.bodyEids) {
        if (state.hasComponent(eid, Move)) moveScratch[eid] = 1;
    }
    queue.writeBuffer(buf, 7 * S * 4, moveScratch, 0, S);
}

const CHAR_DATA_STRIDE = 8;
const CHAR_DATA_BYTES = CHAR_DATA_STRIDE * 4;
let charDataScratch = new Float32Array(0);
let charIndicesScratch = new Uint32Array(0);
const charParamsScratch = new Uint32Array(1);

const charEidToBody = new Map<number, number>();

function rebuildCharacterIndices(gpu: PhysicsGPU): void {
    const eids = gpu.characters;
    const count = eids.length;
    gpu.characterCount = count;
    if (count === 0) return;

    const bodyEids = gpu.bodyEids;
    charEidToBody.clear();
    for (let i = 0; i < bodyEids.length; i++) charEidToBody.set(bodyEids[i], i);

    if (charIndicesScratch.length < count) {
        charIndicesScratch = new Uint32Array(count);
    }
    if (charDataScratch.length < count * CHAR_DATA_STRIDE) {
        charDataScratch = new Float32Array(count * CHAR_DATA_STRIDE);
    }
    charDataScratch.fill(0, 0, count * CHAR_DATA_STRIDE);

    for (let i = 0; i < count; i++) {
        const eid = eids[i];
        charIndicesScratch[i] = charEidToBody.get(eid) ?? 0;
        charDataScratch[i * CHAR_DATA_STRIDE] = Character.maxSlope[eid];
        charDataScratch[i * CHAR_DATA_STRIDE + 5] = Character.mass[eid];
    }

    const indicesSize = count * 4;
    if (gpu.characterIndicesBuffer.size < indicesSize) {
        gpu.characterIndicesBuffer.destroy();
        gpu.characterIndicesBuffer = gpu.device.createBuffer({
            label: "physics-character-indices",
            size: indicesSize,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });
        gpu.characterSweepBindGroup.invalidate();
    }
    gpu.device.queue.writeBuffer(gpu.characterIndicesBuffer, 0, charIndicesScratch, 0, count);

    const dataSize = count * CHAR_DATA_BYTES;
    if (gpu.characterBuffer.size < dataSize) {
        gpu.characterBuffer.destroy();
        gpu.characterBuffer = gpu.device.createBuffer({
            label: "physics-character-data",
            size: dataSize,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST,
        });
        gpu.characterSweepBindGroup.invalidate();
    }

    const groundSize = count * 4;
    if (gpu.characterGroundBuffer.size < groundSize) {
        gpu.characterGroundBuffer.destroy();
        gpu.characterGroundBuffer = gpu.device.createBuffer({
            label: "physics-character-ground",
            size: groundSize,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });
        gpu.characterSweepBindGroup.invalidate();
        const initData = new Uint32Array(count);
        initData.fill(0xffffffff);
        gpu.device.queue.writeBuffer(gpu.characterGroundBuffer, 0, initData);
    }

    charParamsScratch[0] = count;
    gpu.device.queue.writeBuffer(gpu.characterParamsBuffer, 0, charParamsScratch);
}

function uploadCharacterData(gpu: PhysicsGPU): void {
    if (gpu.characterCount === 0) return;
    gpu.device.queue.writeBuffer(
        gpu.characterBuffer,
        0,
        charDataScratch,
        0,
        gpu.characterCount * CHAR_DATA_STRIDE,
    );
}

function updateCharacterInput(gpu: PhysicsGPU): void {
    const dt = gpu.params.dt;
    const vvel = gpu.characterVerticalVelocity;
    const coyote = gpu.characterCoyoteTimers;

    for (let ci = 0; ci < gpu.characters.length; ci++) {
        const eid = gpu.characters[ci];
        const grounded = Character.grounded[eid] > 0.5;
        const coyoteTime = Character.coyoteTime[eid] ?? 0.1;
        let coyoteTimer = coyote.get(eid) ?? 0;

        const g = Character.gravity[eid] ?? 50;
        const jumpVel = Math.sqrt(2 * g * Character.jumpHeight[eid]);
        const wantJump = Character.jump[eid] > 0.5;

        let vy = vvel.get(eid) ?? 0;
        if (grounded) {
            coyoteTimer = coyoteTime;
            vy = 0;
            if (wantJump) {
                vy = jumpVel;
                coyoteTimer = 0;
            }
        } else {
            coyoteTimer -= dt;
            vy -= g * dt;
            if (coyoteTimer > 0 && wantJump) {
                vy = jumpVel;
                coyoteTimer = 0;
            }
        }
        vvel.set(eid, vy);
        coyote.set(eid, coyoteTimer);

        const off = ci * CHAR_DATA_STRIDE;
        charDataScratch[off + 2] = Character.moveX[eid] * dt;
        charDataScratch[off + 3] = vy * dt;
        charDataScratch[off + 4] = Character.moveZ[eid] * dt;
    }
}

function requestCharacterReadback(gpu: PhysicsGPU): void {
    if (gpu.characterCount === 0 || gpu.characterReadbackPending) return;

    const byteSize = gpu.characterCount * CHAR_DATA_BYTES;
    if (gpu.characterReadbackStaging.size < byteSize) {
        gpu.characterReadbackStaging.destroy();
        gpu.characterReadbackStaging = gpu.device.createBuffer({
            label: "physics-character-readback",
            size: byteSize,
            usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
        });
    }

    gpu.characterReadbackPending = true;
    const gen = gpu.bodyGeneration;
    const count = gpu.characterCount;
    const eids = gpu.characters.slice();

    const enc = gpu.device.createCommandEncoder();
    enc.copyBufferToBuffer(gpu.characterBuffer, 0, gpu.characterReadbackStaging, 0, byteSize);
    gpu.device.queue.submit([enc.finish()]);

    gpu.characterReadbackStaging.mapAsync(GPUMapMode.READ, 0, byteSize).then(
        () => {
            if (gpu.bodyGeneration !== gen) {
                gpu.characterReadbackStaging.unmap();
                gpu.characterReadbackPending = false;
                return;
            }
            const mapped = gpu.characterReadbackStaging.getMappedRange(0, byteSize);
            const u32 = new Uint32Array(mapped);
            for (let i = 0; i < count && i < eids.length; i++) {
                Character.grounded[eids[i]] = u32[i * CHAR_DATA_STRIDE + 1] > 0 ? 1 : 0;
            }
            gpu.characterReadbackStaging.unmap();
            gpu.characterReadbackPending = false;
        },
        () => {
            gpu.characterReadbackPending = false;
        },
    );
}


function dispatch(gpu: PhysicsGPU, bodyCount: number, encoder: GPUCommandEncoder): void {
    const bodyWG = Math.ceil(bodyCount / 64);
    const p = gpu.profile;
    if (p) {
        drainProfile(p);
        resetProfile(p);
    }

    const hashWG = Math.ceil(hashCapacity() / 64);
    const rebuildGroup = gpu.rebuildBindGroup.group;

    const ts = (name: string) => (p ? allocSlot(p, name) : undefined);

    rebuildScratch[0] = 0;
    rebuildScratch[1] = hashCapacity();
    rebuildScratch[2] = 0;
    rebuildScratch[3] = 0;
    gpu.device.queue.writeBuffer(gpu.rebuildParamsBuffer, 0, rebuildScratch);

    const prevConstraintCount = gpu.debugReadbackData[SS_CONSTRAINT_COUNT];
    const prevCopySize =
        prevConstraintCount > 0
            ? prevConstraintCount * CONSTRAINT_BYTES
            : maxConstraints() * CONSTRAINT_BYTES;
    encoder.copyBufferToBuffer(
        gpu.solverStateBuffer.buffer,
        SS_CONSTRAINT_COUNT * 4,
        gpu.rebuildParamsBuffer,
        0,
        4,
    );
    // Snapshot last tick's final body positions for render interpolation BEFORE this tick's
    // kinematic uploads and character movement run — otherwise a character's `prev` would
    // equal its post-move position and its motion wouldn't interpolate (visible jitter).
    // `bodyBufferPrev` is read only by the render-interpolation pass, so this reorder is
    // physics-neutral and lets characters and `Move` platforms interpolate smoothly.
    encoder.copyBufferToBuffer(
        gpu.bodyBuffer.buffer,
        0,
        gpu.bodyBufferPrev.buffer,
        0,
        bodyCount * BODY_BYTES,
    );
    beginPass(encoder, gpu.prepareIndirectPipeline, gpu.prepareIndirectBindGroup.group, 1);
    beginPass(encoder, gpu.syncTransformsPipeline, gpu.syncTransformsBindGroup.group, bodyWG);
    if (gpu.characterCount > 0) {
        beginPass(
            encoder,
            gpu.characterApplyPipeline,
            gpu.characterSweepBindGroup.group,
            Math.ceil(gpu.characterCount / 64),
            ts("phys:characterApply"),
        );
    }
    encoder.copyBufferToBuffer(
        gpu.constraintsBuffer.buffer,
        0,
        gpu.prevConstraintsBuffer.buffer,
        0,
        prevCopySize,
    );
    beginPass(encoder, gpu.clearHashPipeline, rebuildGroup, hashWG, ts("phys:rebuild"));
    beginPassIndirect(
        encoder,
        gpu.rebuildPipeline,
        rebuildGroup,
        gpu.indirectBuffer,
        MAX_COLORS * 12,
        ts("phys:rebuild"),
    );

    dispatchPhysicsLBVH(gpu.lbvh, encoder, gpu.device, bodyCount, ts);

    encoder.clearBuffer(gpu.solverStateBuffer.buffer, 0, COUNTERS_SIZE);
    const solverGroup = gpu.solverBindGroup.group;
    const narrowGroup = gpu.narrowBindGroup.group;
    const pairGroup = gpu.pairBindGroup.group;
    const bvhPass = beginComputePass(encoder, ts("phys:broadphase"));
    bvhPass.setPipeline(gpu.bvhTraversalPipeline);
    bvhPass.setBindGroup(0, narrowGroup);
    bvhPass.setBindGroup(1, pairGroup);
    bvhPass.dispatchWorkgroups(bodyWG);
    bvhPass.end();

    beginPass(encoder, gpu.prepareIndirectPipeline, gpu.prepareIndirectBindGroup.group, 1);
    const npPass = beginComputePass(encoder, ts("phys:narrowphase"));
    for (let t = 0; t < NUM_PAIR_TYPES; t++) {
        npPass.setPipeline(gpu.narrowphasePipelines[t]);
        npPass.setBindGroup(0, narrowGroup);
        npPass.setBindGroup(1, pairGroup);
        npPass.dispatchWorkgroupsIndirect(gpu.indirectBuffer, (MAX_COLORS + 1 + t) * 12);
    }
    npPass.end();
    beginPass(
        encoder,
        gpu.detectJointsPipeline,
        solverGroup,
        Math.ceil(gpu.jointSlot.capacity / 64),
        ts("phys:broadphase"),
    );
    beginPass(encoder, gpu.warmstartPipeline, solverGroup, bodyWG, ts("phys:warmstart"));
    encoder.clearBuffer(gpu.forceBuffer.buffer, 0, bodyCount * 32);
    beginPass(encoder, gpu.prepareIndirectPipeline, gpu.prepareIndirectBindGroup.group, 1);
    beginPass(encoder, gpu.initBodyCachePipeline, solverGroup, bodyWG, ts("phys:warmstart"));
    beginPassIndirect(
        encoder,
        gpu.cacheContactCPipeline,
        solverGroup,
        gpu.indirectBuffer,
        MAX_COLORS * 12,
        ts("phys:warmstart"),
    );

    beginPass(encoder, gpu.clearColorPipeline, solverGroup, bodyWG, ts("phys:coloring"));
    beginPassIndirect(
        encoder,
        gpu.countBodyConstraintsPipeline,
        solverGroup,
        gpu.indirectBuffer,
        MAX_COLORS * 12,
        ts("phys:coloring"),
    );
    encoder.copyBufferToBuffer(
        gpu.solverStateBuffer.buffer,
        solverStateSize() + csrHeadsOffset() * 4,
        gpu.csrCountsBuffer.buffer,
        0,
        (capacity() + 1) * 4,
    );
    {
        const pass = beginComputePass(encoder, ts("phys:coloring"));
        dispatchPrefixSum(gpu.csrPrefixSum, pass);
        pass.end();
    }
    encoder.copyBufferToBuffer(
        gpu.csrCountsBuffer.buffer,
        0,
        gpu.solverStateBuffer.buffer,
        solverStateSize() + csrOffsetsOffset() * 4,
        (capacity() + 1) * 4,
    );
    encoder.copyBufferToBuffer(
        gpu.csrCountsBuffer.buffer,
        0,
        gpu.solverStateBuffer.buffer,
        solverStateSize() + csrHeadsOffset() * 4,
        (capacity() + 1) * 4,
    );
    beginPassIndirect(
        encoder,
        gpu.scatterBodyConstraintsPipeline,
        solverGroup,
        gpu.indirectBuffer,
        MAX_COLORS * 12,
        ts("phys:coloring"),
    );
    const iterations = gpu.params.iterations;

    beginPass(encoder, gpu.buildAdjacencyPipeline, solverGroup, bodyWG, ts("phys:coloring"));
    for (let r = 0; r < COLORING_ROUNDS; r++) {
        beginPass(encoder, gpu.graphColorPipeline, solverGroup, bodyWG, ts("phys:coloring"));
    }
    beginPass(encoder, gpu.countColorsPipeline, solverGroup, bodyWG, ts("phys:coloring"));
    beginPass(encoder, gpu.prefixSumColorsPipeline, solverGroup, 1, ts("phys:coloring"));
    beginPass(
        encoder,
        gpu.prepareIndirectPipeline,
        gpu.prepareIndirectBindGroup.group,
        1,
        ts("phys:coloring"),
    );
    beginPass(encoder, gpu.sortBodiesPipeline, solverGroup, bodyWG, ts("phys:coloring"));

    beginPass(encoder, gpu.syncBodyColsPipeline, solverGroup, bodyWG, ts("phys:solve"));

    // Skip empty-color dispatches based on prior-frame's used-color count + safety margin.
    // Mac dispatches cost ~23 µs each; saving 3-5 empty colors saves ~0.3 ms/substep on Mac.
    // Safety margin tolerates color count drifting up by 1-2 between frames; readback may be 1-2 frames stale.
    const lastUsedColors = gpu.debugReadbackData[SS_USED_COLORS] | 0;
    const colorsToRun = lastUsedColors > 0 ? Math.min(MAX_COLORS, lastUsedColors + 2) : MAX_COLORS;

    for (let it = 0; it < iterations; it++) {
        for (let c = 0; c < colorsToRun; c++) {
            beginPassIndirect(
                encoder,
                gpu.primalPipeline,
                solverGroup,
                gpu.indirectBuffer,
                c * 12,
                ts("phys:solve"),
            );
            if (c < colorsToRun - 1) {
                beginPass(encoder, gpu.advanceColorPipeline, solverGroup, 1);
            }
        }
        beginPass(encoder, gpu.resetColorPipeline, solverGroup, 1);

        beginPassIndirect(
            encoder,
            gpu.dualPipeline,
            solverGroup,
            gpu.indirectBuffer,
            MAX_COLORS * 12,
            ts("phys:dual"),
        );
        beginPass(encoder, gpu.advancePipeline, solverGroup, 1, ts("phys:dual"));
    }
    beginPass(encoder, gpu.velocityPipeline, solverGroup, bodyWG, ts("phys:dual"));

    beginPassIndirect(
        encoder,
        gpu.writebackPipeline,
        solverGroup,
        gpu.indirectBuffer,
        MAX_COLORS * 12,
        ts("phys:writeback"),
    );

    beginPassIndirect(
        encoder,
        gpu.emitContactsPipeline,
        gpu.emitContactsBindGroup.group,
        gpu.indirectBuffer,
        MAX_COLORS * 12,
        ts("phys:contacts"),
    );

    if (gpu.characterCount > 0) {
        beginPass(
            encoder,
            gpu.characterSweepPipeline,
            gpu.characterSweepBindGroup.group,
            Math.ceil(gpu.characterCount / 64),
            ts("phys:characterSweep"),
        );
    }

    if (p) resolveProfile(encoder, p);

    gpu.physicsActive = true;

    gpu.device.pushErrorScope("validation");
    gpu.device.queue.submit([encoder.finish()]);
    gpu.device.popErrorScope().then((error) => {
        if (error) console.error("PHYSICS VALIDATION ERROR:", error.message);
    });
}


const PhysicsSystem: System = {
    group: "fixed",

    dispose(state: State) {
        const gpu = Physics.from(state);
        if (!gpu) return;
        gpu.bodyBuffer.buffer.destroy();
        gpu.bodyBufferPrev.buffer.destroy();
        gpu.bodyColsBuffer.buffer.destroy();
        gpu.constraintsBuffer.buffer.destroy();
        gpu.prevConstraintsBuffer.buffer.destroy();
        gpu.rebuildParamsBuffer.destroy();
        gpu.warmstartBuffer.buffer.destroy();
        gpu.solverStateBuffer.buffer.destroy();
        gpu.jointsBuffer.destroy();
        gpu.paramsBuffer.destroy();
        gpu.indirectBuffer.destroy();
        gpu.csrCountsBuffer.buffer.destroy();
        gpu.unpackTransformBuffer.buffer.destroy();
        gpu.sizesBuffer.buffer.destroy();
        gpu.shapesBuffer.buffer.destroy();
        gpu.bodyPropsBuffer.buffer.destroy();
        gpu.eidsBuffer.buffer.destroy();
        gpu.packParamsBuffer.destroy();
        gpu.readbackStaging.destroy();
        gpu.compactBuffer.buffer.destroy();
        gpu.compactParamsBuffer.destroy();
        gpu.pairBuffer.buffer.destroy();
        gpu.hullDataBuffer.buffer.destroy();
        gpu.hullIdsBuffer.buffer.destroy();
        gpu.characterBuffer.destroy();
        gpu.characterIndicesBuffer.destroy();
        gpu.characterParamsBuffer.destroy();
        gpu.characterGroundBuffer.destroy();
        gpu.characterReadbackStaging.destroy();
        disposePrefixSum(gpu.csrPrefixSum);
        disposePhysicsLBVH(gpu.lbvh);
        if (gpu.profile) {
            gpu.profile.querySet.destroy();
            gpu.profile.resolveBuffer.destroy();
            gpu.profile.readBuffer.destroy();
        }
    },

    update(state: State) {
        const gpu = Physics.from(state);
        if (!gpu) return;

        if (capacity() !== gpu.cachedCapacity) {
            gpu.cachedCapacity = capacity();
            rebuildPrefixSum(gpu.csrPrefixSum, gpu.csrCountsBuffer.buffer, capacity() + 1);
            for (const eid of gpu.bodyEids) pushChange(gpu, eid + 1);
            gpu.bodyEids.length = 0;
        }

        if (gpu.readbackReady) {
            processReadback(state, gpu);
            gpu.readbackReady = false;
        }

        const encoder = gpu.device.createCommandEncoder();

        processBodyChanges(gpu, state, encoder);
        rebuildCharacterIndices(gpu);
        updateCharacterInput(gpu);
        uploadCharacterData(gpu);
        syncTransforms(gpu, state);
        packForces(gpu, state);

        const bodyCount = gpu.bodyEids.length;
        if (bodyCount === 0) {
            gpu.device.queue.submit([encoder.finish()]);
            return;
        }

        uploadParams(gpu, bodyCount);
        dispatch(gpu, bodyCount, encoder);

        if (gpu.profile) readProfile(gpu.profile);

        requestReadback(gpu, state.time.fixedTick);
        requestCharacterReadback(gpu);
    },
};

function createInterpolationNode(
    physics: { bodyBufferPrev: GBuf; bodyBuffer: GBuf; eidsBuffer: GBuf },
    matrices: GBuf,
    getAlpha: () => number,
    getBodyCount: () => number,
    isReady: () => boolean,
    hasPendingChanges: () => boolean,
): ComputeNode {
    let pipeline: GPUComputePipeline | null = null;
    let interpBinding: Binding | null = null;
    let paramsBuffer: GPUBuffer | null = null;
    let paramsData: Float32Array | null = null;
    let paramsU32: Uint32Array | null = null;

    return {
        name: "physics-interpolation",
        scope: "frame",
        inputs: ["matrices"],
        outputs: ["matrices"],

        async prepare(device: GPUDevice) {
            const module = device.createShaderModule({ code: interpolateWGSL });
            pipeline = await device.createComputePipelineAsync({
                label: "interpolate",
                layout: "auto",
                compute: { module, entryPoint: "interpolate" },
            });
            paramsBuffer = device.createBuffer({
                label: "interp-params",
                size: 8,
                usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
            });
            const pb = paramsBuffer;
            interpBinding = binding(device, pipeline.getBindGroupLayout(0), () => [
                { binding: 0, resource: { buffer: physics.bodyBufferPrev.buffer } },
                { binding: 1, resource: { buffer: physics.bodyBuffer.buffer } },
                { binding: 2, resource: { buffer: physics.eidsBuffer.buffer } },
                { binding: 3, resource: { buffer: pb } },
                { binding: 4, resource: { buffer: matrices.buffer } },
            ]);
            paramsData = new Float32Array(2);
            paramsU32 = new Uint32Array(paramsData.buffer);
        },

        execute(ctx: ExecutionContext) {
            if (!pipeline || !interpBinding || !paramsBuffer || !paramsData || !paramsU32) return;
            if (!isReady()) return;
            if (hasPendingChanges()) return;

            const bodyCount = getBodyCount();
            if (bodyCount === 0) return;

            paramsData[0] = getAlpha();
            paramsU32[1] = bodyCount;
            ctx.queue.writeBuffer(paramsBuffer, 0, paramsData as Float32Array<ArrayBuffer>);

            const pass = beginComputePass(
                ctx.encoder,
                ctx.timestampWrites?.("physics-interpolation"),
            );
            pass.setPipeline(pipeline);
            pass.setBindGroup(0, interpBinding.group);
            pass.dispatchWorkgroups(Math.ceil(bodyCount / 64));
            pass.end();
        },
    };
}

export const PhysicsPlugin: Plugin = {
    name: "Physics",
    dependencies: [ComputePlugin, RenderPlugin],
    systems: [PhysicsSystem],
    components: { Body, Force, Impulse, Velocity, BallJoint, SpringJoint, Character, Move },

    async initialize(state: State) {
        const compute = Compute.from(state);
        if (!compute) {
            console.error("PhysicsPlugin: Compute resource not available");
            return;
        }

        const gpu = await createGPU(compute.device);
        state.setResource(Physics, gpu);
        state.setResource(Contacts, {
            prevData: new Uint32Array(MAX_CONTACTS * CONTACT_STRIDE),
            prevCount: 0,
            prevOverflow: 0,
            prevTick: -1,
            currentData: new Uint32Array(MAX_CONTACTS * CONTACT_STRIDE),
            currentCount: 0,
            currentOverflow: 0,
            currentTick: -1,
        });

        state.observe(onAdd(Body), (eid) => pushChange(gpu, eid + 1));
        state.observe(onRemove(Body), (eid) => pushChange(gpu, -(eid + 1)));

        const markJointsDirty = () => {
            gpu.jointsNeedUpload = true;
        };
        state.observe(onAdd(BallJoint), markJointsDirty);
        state.observe(onRemove(BallJoint), markJointsDirty);
        state.observe(onAdd(SpringJoint), markJointsDirty);
        state.observe(onRemove(SpringJoint), markJointsDirty);

        state.observe(onAdd(Character), (eid) => {
            gpu.characters.push(eid);
        });
        state.observe(onRemove(Character), (eid) => {
            const idx = gpu.characters.indexOf(eid);
            if (idx >= 0) gpu.characters.splice(idx, 1);
            gpu.characterVerticalVelocity.delete(eid);
            gpu.characterCoyoteTimers.delete(eid);
        });

        const render = Render.from(state);
        if (render) {
            const interpolationNode = createInterpolationNode(
                gpu,
                render.matrices,
                () => state.scheduler.accumulator / Time.FIXED_DT,
                () => gpu.bodyEids.length,
                () => gpu.physicsActive,
                () => gpu.pendingChangeCount > 0,
            );
            compute.graph.add(interpolationNode);
        }

        if (gpu.profile) {
            GpuProfile.from(state)?.push(gpu.profile.durations);
        }
    },
};
