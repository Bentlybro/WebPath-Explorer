// thin wrappers over beginComputePass: set pipeline + bind group + dispatch in one call.
import { beginComputePass } from "../../compute";

export function beginPass(
    encoder: GPUCommandEncoder,
    pipeline: GPUComputePipeline,
    bindGroup: GPUBindGroup,
    workgroups: number,
    timestampWrites?: GPUComputePassTimestampWrites,
): void {
    const pass = beginComputePass(encoder, timestampWrites);
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(workgroups);
    pass.end();
}

export function beginPassIndirect(
    encoder: GPUCommandEncoder,
    pipeline: GPUComputePipeline,
    bindGroup: GPUBindGroup,
    indirectBuffer: GPUBuffer,
    indirectOffset: number,
    timestampWrites?: GPUComputePassTimestampWrites,
): void {
    const pass = beginComputePass(encoder, timestampWrites);
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroupsIndirect(indirectBuffer, indirectOffset);
    pass.end();
}
