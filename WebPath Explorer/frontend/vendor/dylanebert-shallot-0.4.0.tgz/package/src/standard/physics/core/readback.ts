// GPU -> CPU sync: async compact readback of transforms + contacts, applied to ECS.
import type { State } from "../../../engine";
import { transformWasm } from "../../transforms/core";
import { beginPass } from "./pass";
import { Contacts } from "../contact";
import { Body } from "../components";
import { checkOverflows } from "../body";
import {
    COUNTERS_SIZE,
    CONTACTS_BYTES,
    MAX_CONTACTS,
    CONTACT_STRIDE,
    SS_CONTACT_COUNT,
    SS_CONTACT_OVERFLOW,
} from "../solver.wgsl";
import { COMPACT_BYTES, COMPACT_STRIDE, BODY_BYTES } from "../utility.wgsl";
import type { PhysicsGPU } from "../gpu";

const compactParamsScratch = new Uint32Array(1);

export function requestReadback(gpu: PhysicsGPU, tick: number): void {
    if (gpu.readbackPending) return;
    const bodyCount = gpu.bodyEids.length;
    if (bodyCount === 0) return;

    gpu.readbackPending = true;
    gpu.readbackGeneration = gpu.bodyGeneration;
    gpu.readbackBodyCount = bodyCount;
    gpu.readbackTick = tick;

    const compactByteSize = bodyCount * COMPACT_BYTES;
    const contactsOffset = COUNTERS_SIZE + compactByteSize;
    const totalSize = contactsOffset + CONTACTS_BYTES;

    if (gpu.readbackStaging.size < totalSize) {
        gpu.readbackStaging.destroy();
        gpu.readbackStaging = gpu.device.createBuffer({
            label: "physics-readback-staging",
            size: totalSize,
            usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
        });
    }

    if (gpu.transformReadbackData.length < bodyCount * COMPACT_STRIDE) {
        gpu.transformReadbackData = new Float32Array(bodyCount * COMPACT_STRIDE);
    }

    compactParamsScratch[0] = bodyCount;
    gpu.device.queue.writeBuffer(gpu.compactParamsBuffer, 0, compactParamsScratch);

    const enc = gpu.device.createCommandEncoder();
    const bodyWG = Math.ceil(bodyCount / 64);
    beginPass(enc, gpu.compactPipeline, gpu.compactBindGroup.group, bodyWG);
    enc.copyBufferToBuffer(gpu.solverStateBuffer.buffer, 0, gpu.readbackStaging, 0, COUNTERS_SIZE);
    enc.copyBufferToBuffer(
        gpu.compactBuffer.buffer,
        0,
        gpu.readbackStaging,
        COUNTERS_SIZE,
        compactByteSize,
    );
    enc.copyBufferToBuffer(
        gpu.contactsBuffer,
        0,
        gpu.readbackStaging,
        contactsOffset,
        CONTACTS_BYTES,
    );
    gpu.device.queue.submit([enc.finish()]);

    gpu.readbackStaging.mapAsync(GPUMapMode.READ, 0, totalSize).then(
        () => {
            if (gpu.readbackGeneration !== gpu.bodyGeneration) {
                gpu.readbackStaging.unmap();
                gpu.readbackPending = false;
                return;
            }
            const mapped = gpu.readbackStaging.getMappedRange(0, totalSize);
            const bytes = new ArrayBuffer(totalSize);
            new Uint8Array(bytes).set(new Uint8Array(mapped));
            gpu.readbackStaging.unmap();

            gpu.debugReadbackData.set(new Uint32Array(bytes, 0, COUNTERS_SIZE / 4));
            gpu.transformReadbackData.set(
                new Float32Array(bytes, COUNTERS_SIZE, bodyCount * COMPACT_STRIDE),
            );
            gpu.contactScratch.set(
                new Uint32Array(bytes, contactsOffset, MAX_CONTACTS * CONTACT_STRIDE),
            );

            gpu.readbackReady = true;
            gpu.readbackPending = false;
        },
        () => {
            gpu.readbackPending = false;
        },
    );
}

export function processReadback(state: State, gpu: PhysicsGPU): void {
    if (gpu.readbackGeneration !== gpu.bodyGeneration) return;
    const tick = gpu.readbackTick;
    const bodyCount = gpu.readbackBodyCount;

    checkOverflows(gpu.debugReadbackData, tick, bodyCount);

    const rawCount = gpu.debugReadbackData[SS_CONTACT_COUNT];
    const overflow = gpu.debugReadbackData[SS_CONTACT_OVERFLOW];
    gpu.contactScratchCount = Math.min(rawCount, MAX_CONTACTS);
    gpu.contactScratchOverflow = overflow;
    if (overflow > 0) {
        console.warn(
            `[phys] tick=${tick} CONTACT OVERFLOW: ${overflow} dropped (cap=${MAX_CONTACTS})`,
        );
    }

    const contacts = Contacts.from(state);
    if (contacts) {
        const tmp = contacts.prevData;
        contacts.prevData = contacts.currentData;
        contacts.prevCount = contacts.currentCount;
        contacts.prevOverflow = contacts.currentOverflow;
        contacts.prevTick = contacts.currentTick;
        contacts.currentData = tmp;
        contacts.currentData.set(gpu.contactScratch);
        contacts.currentCount = gpu.contactScratchCount;
        contacts.currentOverflow = overflow;
        contacts.currentTick = tick;
    }

    const data = gpu.transformReadbackData;
    const { posX, posY, posZ, quatX, quatY, quatZ, quatW } = transformWasm;
    const eids = gpu.bodyEids;

    const charEids = gpu.characters;
    for (let i = 0; i < bodyCount; i++) {
        const eid = eids[i];
        if (Body.mass[eid] <= 0 && !charEids.includes(eid)) continue;
        const o = i * COMPACT_STRIDE;
        posX[eid] = data[o];
        posY[eid] = data[o + 1];
        posZ[eid] = data[o + 2];
        quatX[eid] = data[o + 3];
        quatY[eid] = data[o + 4];
        quatZ[eid] = data[o + 5];
        quatW[eid] = data[o + 6];
    }
    gpu.lastSyncTick = tick;
}

export async function readBodies(gpu: PhysicsGPU): Promise<Float32Array> {
    const count = gpu.bodyEids.length;
    if (count === 0) return new Float32Array(0);
    const byteSize = count * BODY_BYTES;
    const staging = gpu.device.createBuffer({
        size: byteSize,
        usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
    });
    const enc = gpu.device.createCommandEncoder();
    enc.copyBufferToBuffer(gpu.bodyBuffer.buffer, 0, staging, 0, byteSize);
    gpu.device.queue.submit([enc.finish()]);
    await staging.mapAsync(GPUMapMode.READ, 0, byteSize);
    const mapped = staging.getMappedRange(0, byteSize);
    const data = new Float32Array(mapped.slice(0));
    staging.unmap();
    staging.destroy();
    return data;
}
