// One-time GPU resource construction for the physics solver: buffers, bind-group
// layouts, and compute pipelines. Pure factory — returns the PhysicsGPU state object.
import { capacity } from "../../../engine";
import { gbuf, binding } from "../../compute";
import { createProfileState, type ProfileState } from "../../compute/core";
import { createPrefixSum } from "../../radix";
import { createPhysicsLBVH } from "../lbvh";
import { characterSweepWGSL, characterApplyWGSL } from "../character.wgsl";
import { bvhTraversalWGSL } from "../broadphase.wgsl";
import { narrowphaseWGSL, PAIR_TYPE_NAMES } from "../narrowphase.wgsl";
import {
    solverWGSL,
    coloringWGSL,
    maxConstraints,
    CONSTRAINT_BYTES,
    WARMSTART_BYTES,
    hashCapacity,
    JOINT_BYTES,
    MAX_COLORS,
    solverStateSize,
    HASH_REGION_OFFSET,
    colorDataSize,
    COUNTERS_SIZE,
    MAX_CONTACTS,
    CONTACT_STRIDE,
    CONTACTS_BYTES,
    NUM_PAIR_TYPES,
    BODY_COL_COUNT,
} from "../solver.wgsl";
import {
    packWGSL,
    rebuildWGSL,
    syncTransformsWGSL,
    compactWGSL,
    emitContactsWGSL,
    prepareIndirectWGSL,
    BODY_BYTES,
    COMPACT_BYTES,
} from "../utility.wgsl";
import type { PhysicsGPU, SolverParams } from "../gpu";

const PARAMS_SIZE = 64;

const DEFAULT_PARAMS: SolverParams = {
    dt: 1 / 60,
    gravity: -10,
    iterations: 4,
    alpha: 0.99,
    betaLin: 100000,
    betaAng: 100,
    gamma: 0.999,
};

export async function createGPU(device: GPUDevice): Promise<PhysicsGPU> {
    const StorageDst = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST;
    const StorageDstSrc = StorageDst | GPUBufferUsage.COPY_SRC;
    const soaStorage = StorageDst;

    const bodyBuffer = gbuf(device, "physics-bodies", StorageDstSrc, (c) => c * BODY_BYTES);
    const bodyBufferPrev = gbuf(device, "physics-bodies-prev", StorageDst, (c) => c * BODY_BYTES);
    const bodyColsBuffer = gbuf(
        device,
        "physics-bodyCols",
        StorageDst,
        (c) => c * BODY_COL_COUNT * 16,
    );

    const constraintsBuffer = gbuf(
        device,
        "physics-constraints",
        StorageDstSrc,
        () => maxConstraints() * CONSTRAINT_BYTES,
    );
    const prevConstraintsBuffer = gbuf(
        device,
        "physics-prevConstraints",
        StorageDstSrc,
        () => maxConstraints() * CONSTRAINT_BYTES,
    );

    const warmstartBuffer = gbuf(
        device,
        "physics-warmstarts",
        StorageDst,
        () => hashCapacity() * WARMSTART_BYTES,
    );

    const solverStateBuffer = gbuf(
        device,
        "physics-solverState",
        StorageDstSrc,
        () => solverStateSize() + colorDataSize(),
    );
    const initData = new Uint32Array(hashCapacity()).fill(0xffffffff);
    device.queue.writeBuffer(solverStateBuffer.buffer, HASH_REGION_OFFSET, initData);

    const joints = {
        buffer: device.createBuffer({
            label: "physics-joints",
            size: 16 * JOINT_BYTES,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        }),
        capacity: 16,
    };

    const csrCountsBuffer = gbuf(
        device,
        "physics-csrCounts",
        GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST,
        (c) => (c + 1) * 4,
    );

    const indirectBuffer = device.createBuffer({
        label: "physics-indirect",
        size: (MAX_COLORS + 1 + NUM_PAIR_TYPES) * 12,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.INDIRECT,
    });

    const paramsBuffer = device.createBuffer({
        label: "physics-params",
        size: PARAMS_SIZE,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });

    const unpackTransformBuffer = gbuf(
        device,
        "physics-unpackTransform",
        StorageDstSrc,
        (c) => c * 8 * 4,
    );

    const sizesBuffer = gbuf(device, "physics-sizes", soaStorage, (c) => c * 16);
    const shapesBuffer = gbuf(device, "physics-shapes", soaStorage, (c) => Math.ceil(c / 4) * 4);
    const bodyPropsBuffer = gbuf(device, "physics-bodyProps", soaStorage, (c) => c * 16);
    const eidsBuffer = gbuf(device, "physics-eids", soaStorage, (c) => c * 4);
    const forceBuffer = gbuf(device, "physics-forces", StorageDst, (c) => c * 32);
    const packParamsBuffer = device.createBuffer({
        label: "physics-packParams",
        size: 16,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });

    const rebuildParamsBuffer = device.createBuffer({
        label: "physics-rebuildParams",
        size: 16,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });

    const pairBuffer = gbuf(
        device,
        "physics-pairs",
        GPUBufferUsage.STORAGE,
        () => NUM_PAIR_TYPES * maxConstraints() * 8,
    );

    const hullDataBuffer = {
        buffer: device.createBuffer({
            label: "physics-hullData",
            size: 32,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        }),
    };
    const hullIdsBuffer = gbuf(device, "physics-hullIds", soaStorage, (c) => c * 4);

    const solverModule = device.createShaderModule({ code: solverWGSL });
    const coloringModule = device.createShaderModule({ code: coloringWGSL });
    const bvhTraversalModule = device.createShaderModule({ code: bvhTraversalWGSL });
    const narrowphaseModules = Array.from({ length: NUM_PAIR_TYPES }, (_, i) =>
        device.createShaderModule({ code: narrowphaseWGSL(i) }),
    );
    const packModule = device.createShaderModule({ code: packWGSL });
    const rebuildModule = device.createShaderModule({ code: rebuildWGSL });
    const prepareIndirectModule = device.createShaderModule({ code: prepareIndirectWGSL });
    const syncTransformsModule = device.createShaderModule({ code: syncTransformsWGSL });
    const compactModule = device.createShaderModule({ code: compactWGSL });
    const emitContactsModule = device.createShaderModule({ code: emitContactsWGSL });
    const characterSweepModule = device.createShaderModule({ code: characterSweepWGSL });
    const characterApplyModule = device.createShaderModule({ code: characterApplyWGSL });

    const vis = GPUShaderStage.COMPUTE;
    const baseEntries = [
        { binding: 0, visibility: vis, buffer: { type: "storage" as const } },
        { binding: 1, visibility: vis, buffer: { type: "uniform" as const } },
        { binding: 2, visibility: vis, buffer: { type: "storage" as const } },
        { binding: 3, visibility: vis, buffer: { type: "storage" as const } },
        { binding: 4, visibility: vis, buffer: { type: "storage" as const } },
        { binding: 5, visibility: vis, buffer: { type: "storage" as const } },
        { binding: 6, visibility: vis, buffer: { type: "read-only-storage" as const } },
        { binding: 7, visibility: vis, buffer: { type: "read-only-storage" as const } },
        { binding: 8, visibility: vis, buffer: { type: "read-only-storage" as const } },
    ];
    const bodyBindGroupLayout = device.createBindGroupLayout({ entries: baseEntries });
    const solverBindGroupLayout = device.createBindGroupLayout({
        entries: [
            ...baseEntries,
            { binding: 9, visibility: vis, buffer: { type: "read-only-storage" as const } },
            { binding: 10, visibility: vis, buffer: { type: "storage" as const } },
        ],
    });

    const solverLayout = device.createPipelineLayout({
        bindGroupLayouts: [solverBindGroupLayout],
    });

    const pairBindGroupLayout = device.createBindGroupLayout({
        entries: [
            { binding: 0, visibility: vis, buffer: { type: "storage" } },
            { binding: 1, visibility: vis, buffer: { type: "read-only-storage" as const } },
        ],
    });
    const bvhNarrowLayout = device.createPipelineLayout({
        bindGroupLayouts: [bodyBindGroupLayout, pairBindGroupLayout],
    });

    const rebuildBindGroupLayout = device.createBindGroupLayout({
        entries: [
            { binding: 0, visibility: vis, buffer: { type: "storage" } },
            { binding: 1, visibility: vis, buffer: { type: "storage" } },
            { binding: 2, visibility: vis, buffer: { type: "read-only-storage" } },
            { binding: 3, visibility: vis, buffer: { type: "uniform" } },
        ],
    });
    const rebuildLayout = device.createPipelineLayout({
        bindGroupLayouts: [rebuildBindGroupLayout],
    });

    const emitContactsBindGroupLayout = device.createBindGroupLayout({
        entries: [
            { binding: 0, visibility: vis, buffer: { type: "read-only-storage" as const } },
            { binding: 1, visibility: vis, buffer: { type: "read-only-storage" as const } },
            { binding: 2, visibility: vis, buffer: { type: "storage" as const } },
            { binding: 3, visibility: vis, buffer: { type: "storage" as const } },
        ],
    });
    const emitContactsLayout = device.createPipelineLayout({
        bindGroupLayouts: [emitContactsBindGroupLayout],
    });

    const characterBindGroupLayout = device.createBindGroupLayout({
        entries: [
            { binding: 0, visibility: vis, buffer: { type: "storage" as const } },
            { binding: 1, visibility: vis, buffer: { type: "read-only-storage" as const } },
            { binding: 2, visibility: vis, buffer: { type: "read-only-storage" as const } },
            { binding: 3, visibility: vis, buffer: { type: "read-only-storage" as const } },
            { binding: 4, visibility: vis, buffer: { type: "storage" as const } },
            { binding: 5, visibility: vis, buffer: { type: "read-only-storage" as const } },
            { binding: 6, visibility: vis, buffer: { type: "uniform" as const } },
            { binding: 7, visibility: vis, buffer: { type: "storage" as const } },
        ],
    });
    const characterLayout = device.createPipelineLayout({
        bindGroupLayouts: [characterBindGroupLayout],
    });

    const solverEntryPoints = [
        "warmstartBodies",
        "detectJoints",
        "initBodyCache",
        "cacheContactC",
        "solveDual",
        "advanceIteration",
        "computeVelocities",
        "writebackWarmstarts",
        "solvePrimal",
        "advanceColor",
        "resetColor",
        "syncBodyCols",
    ] as const;

    const coloringEntryPoints = [
        "clearColorBuffers",
        "countBodyConstraints",
        "scatterBodyConstraints",
        "buildAdjacencyList",
        "graphColor",
        "countColors",
        "prefixSumColors",
        "sortBodiesByColor",
    ] as const;

    const [
        solverPipelineEntries,
        coloringPipelineEntries,
        bvhTraversalPipeline,
        narrowphasePipelines,
        packPipeline,
        clearHashPipeline,
        rebuildPipeline,
        prepareIndirectPipeline,
        syncTransformsPipeline,
        compactPipeline,
        emitContactsPipeline,
        lbvh,
        csrPrefixSum,
        characterSweepPipeline,
        characterApplyPipeline,
    ] = await Promise.all([
        Promise.all(
            solverEntryPoints.map(async (ep) => {
                const pl = await device.createComputePipelineAsync({
                    label: ep,
                    layout: solverLayout,
                    compute: { module: solverModule, entryPoint: ep },
                });
                return [ep, pl] as const;
            }),
        ),
        Promise.all(
            coloringEntryPoints.map(async (ep) => {
                const pl = await device.createComputePipelineAsync({
                    label: ep,
                    layout: solverLayout,
                    compute: { module: coloringModule, entryPoint: ep },
                });
                return [ep, pl] as const;
            }),
        ),
        device.createComputePipelineAsync({
            label: "broadphase",
            layout: bvhNarrowLayout,
            compute: { module: bvhTraversalModule, entryPoint: "broadphase" },
        }),
        Promise.all(
            narrowphaseModules.map((module, i) =>
                device.createComputePipelineAsync({
                    label: `narrowphase-${PAIR_TYPE_NAMES[i]}`,
                    layout: bvhNarrowLayout,
                    compute: { module, entryPoint: "narrowphase" },
                }),
            ),
        ),
        device.createComputePipelineAsync({
            label: "packBodies",
            layout: "auto",
            compute: { module: packModule, entryPoint: "packBodies" },
        }),
        device.createComputePipelineAsync({
            label: "clearHash",
            layout: rebuildLayout,
            compute: { module: rebuildModule, entryPoint: "clearHash" },
        }),
        device.createComputePipelineAsync({
            label: "rebuildWarm",
            layout: rebuildLayout,
            compute: { module: rebuildModule, entryPoint: "rebuildWarm" },
        }),
        device.createComputePipelineAsync({
            label: "prepareIndirect",
            layout: "auto",
            compute: { module: prepareIndirectModule, entryPoint: "main" },
        }),
        device.createComputePipelineAsync({
            label: "syncTransforms",
            layout: "auto",
            compute: { module: syncTransformsModule, entryPoint: "syncTransforms" },
        }),
        device.createComputePipelineAsync({
            label: "readback",
            layout: "auto",
            compute: { module: compactModule, entryPoint: "readback" },
        }),
        device.createComputePipelineAsync({
            label: "emitContacts",
            layout: emitContactsLayout,
            compute: { module: emitContactsModule, entryPoint: "emitContacts" },
        }),
        createPhysicsLBVH(device, bodyBuffer, paramsBuffer),
        createPrefixSum(device, csrCountsBuffer.buffer, capacity() + 1),
        device.createComputePipelineAsync({
            label: "characterSweep",
            layout: characterLayout,
            compute: { module: characterSweepModule, entryPoint: "characterSweep" },
        }),
        device.createComputePipelineAsync({
            label: "characterApply",
            layout: characterLayout,
            compute: { module: characterApplyModule, entryPoint: "characterApply" },
        }),
    ]);

    const pipelines = Object.fromEntries([
        ...solverPipelineEntries,
        ...coloringPipelineEntries,
    ]) as Record<
        (typeof solverEntryPoints)[number] | (typeof coloringEntryPoints)[number],
        GPUComputePipeline
    >;

    const rebuildBindGroup = binding(device, rebuildBindGroupLayout, () => [
        {
            binding: 0,
            resource: {
                buffer: solverStateBuffer.buffer,
                offset: HASH_REGION_OFFSET,
                size: hashCapacity() * 4,
            },
        },
        { binding: 1, resource: { buffer: warmstartBuffer.buffer } },
        { binding: 2, resource: { buffer: prevConstraintsBuffer.buffer } },
        { binding: 3, resource: { buffer: rebuildParamsBuffer } },
    ]);

    const prepareIndirectBindGroup = binding(
        device,
        prepareIndirectPipeline.getBindGroupLayout(0),
        () => [
            { binding: 0, resource: { buffer: solverStateBuffer.buffer } },
            { binding: 1, resource: { buffer: indirectBuffer } },
        ],
    );

    const narrowBindGroupEntries = () => [
        { binding: 0, resource: { buffer: bodyBuffer.buffer } },
        { binding: 1, resource: { buffer: paramsBuffer } },
        { binding: 2, resource: { buffer: constraintsBuffer.buffer } },
        { binding: 3, resource: { buffer: warmstartBuffer.buffer } },
        { binding: 4, resource: { buffer: joints.buffer } },
        { binding: 5, resource: { buffer: solverStateBuffer.buffer } },
        { binding: 6, resource: { buffer: lbvh.lbvh.treeNodes } },
        { binding: 7, resource: { buffer: lbvh.lbvh.sortedIds } },
        { binding: 8, resource: { buffer: lbvh.bodyAABBs.buffer } },
    ];
    const narrowBindGroup = binding(device, bodyBindGroupLayout, narrowBindGroupEntries);
    const solverBindGroup = binding(device, solverBindGroupLayout, () => [
        ...narrowBindGroupEntries(),
        { binding: 9, resource: { buffer: forceBuffer.buffer } },
        { binding: 10, resource: { buffer: bodyColsBuffer.buffer } },
    ]);

    const pairBindGroup = binding(device, pairBindGroupLayout, () => [
        { binding: 0, resource: { buffer: pairBuffer.buffer } },
        { binding: 1, resource: { buffer: hullDataBuffer.buffer } },
    ]);

    const packBindGroup = binding(device, packPipeline.getBindGroupLayout(0), () => [
        { binding: 0, resource: { buffer: sizesBuffer.buffer } },
        { binding: 1, resource: { buffer: shapesBuffer.buffer } },
        { binding: 2, resource: { buffer: bodyPropsBuffer.buffer } },
        { binding: 3, resource: { buffer: eidsBuffer.buffer } },
        { binding: 4, resource: { buffer: bodyBuffer.buffer } },
        { binding: 5, resource: { buffer: packParamsBuffer } },
        { binding: 6, resource: { buffer: unpackTransformBuffer.buffer } },
        { binding: 7, resource: { buffer: hullIdsBuffer.buffer } },
    ]);

    const syncTransformsBindGroup = binding(
        device,
        syncTransformsPipeline.getBindGroupLayout(0),
        () => [
            { binding: 0, resource: { buffer: bodyBuffer.buffer } },
            { binding: 1, resource: { buffer: eidsBuffer.buffer } },
            { binding: 2, resource: { buffer: unpackTransformBuffer.buffer } },
            { binding: 3, resource: { buffer: packParamsBuffer } },
        ],
    );

    const compactBuffer = gbuf(
        device,
        "physics-compact",
        GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
        () => capacity() * COMPACT_BYTES,
    );
    const compactParamsBuffer = device.createBuffer({
        label: "physics-compact-params",
        size: 4,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    const compactBindGroup = binding(device, compactPipeline.getBindGroupLayout(0), () => [
        { binding: 0, resource: { buffer: bodyBuffer.buffer } },
        { binding: 1, resource: { buffer: compactBuffer.buffer } },
        { binding: 2, resource: { buffer: compactParamsBuffer } },
    ]);

    const contactsBuffer = device.createBuffer({
        label: "physics-contacts",
        size: CONTACTS_BYTES,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
    });
    const emitContactsBindGroup = binding(device, emitContactsBindGroupLayout, () => [
        { binding: 0, resource: { buffer: bodyBuffer.buffer } },
        { binding: 1, resource: { buffer: constraintsBuffer.buffer } },
        { binding: 2, resource: { buffer: solverStateBuffer.buffer } },
        { binding: 3, resource: { buffer: contactsBuffer } },
    ]);

    const characterBuffer = device.createBuffer({
        label: "physics-character-data",
        size: 64,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST,
    });
    const characterIndicesBuffer = device.createBuffer({
        label: "physics-character-indices",
        size: 16,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
    const characterParamsBuffer = device.createBuffer({
        label: "physics-character-params",
        size: 4,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    const characterGroundBuffer = device.createBuffer({
        label: "physics-character-ground",
        size: 16,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
    const characterSweepBindGroup = binding(device, characterBindGroupLayout, () => [
        { binding: 0, resource: { buffer: bodyBuffer.buffer } },
        { binding: 1, resource: { buffer: lbvh.lbvh.treeNodes } },
        { binding: 2, resource: { buffer: lbvh.lbvh.sortedIds } },
        { binding: 3, resource: { buffer: lbvh.bodyAABBs.buffer } },
        { binding: 4, resource: { buffer: characterBuffer } },
        { binding: 5, resource: { buffer: characterIndicesBuffer } },
        { binding: 6, resource: { buffer: characterParamsBuffer } },
        { binding: 7, resource: { buffer: characterGroundBuffer } },
    ]);
    const characterReadbackStaging = device.createBuffer({
        label: "physics-character-readback",
        size: 64,
        usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
    });

    const paramsData = new ArrayBuffer(PARAMS_SIZE);
    const profile: ProfileState | null = device.features.has("timestamp-query")
        ? createProfileState(device, 1024)
        : null;

    return {
        device,
        lbvh,
        warmstartPipeline: pipelines.warmstartBodies,
        clearHashPipeline,
        rebuildPipeline,
        bvhTraversalPipeline,
        narrowphasePipelines,
        pairBuffer,
        pairBindGroup,
        detectJointsPipeline: pipelines.detectJoints,
        initBodyCachePipeline: pipelines.initBodyCache,
        cacheContactCPipeline: pipelines.cacheContactC,
        dualPipeline: pipelines.solveDual,
        advancePipeline: pipelines.advanceIteration,
        velocityPipeline: pipelines.computeVelocities,
        writebackPipeline: pipelines.writebackWarmstarts,
        clearColorPipeline: pipelines.clearColorBuffers,
        countBodyConstraintsPipeline: pipelines.countBodyConstraints,
        scatterBodyConstraintsPipeline: pipelines.scatterBodyConstraints,
        buildAdjacencyPipeline: pipelines.buildAdjacencyList,
        graphColorPipeline: pipelines.graphColor,
        countColorsPipeline: pipelines.countColors,
        prefixSumColorsPipeline: pipelines.prefixSumColors,
        sortBodiesPipeline: pipelines.sortBodiesByColor,
        primalPipeline: pipelines.solvePrimal,
        advanceColorPipeline: pipelines.advanceColor,
        resetColorPipeline: pipelines.resetColor,
        syncBodyColsPipeline: pipelines.syncBodyCols,
        prepareIndirectPipeline,
        prepareIndirectBindGroup,
        packPipeline,
        syncTransformsPipeline,
        syncTransformsBindGroup,
        compactPipeline,
        compactBindGroup,
        compactBuffer,
        compactParamsBuffer,
        emitContactsPipeline,
        emitContactsBindGroup,
        contactsBuffer,
        bodyBuffer,
        bodyBufferPrev,
        bodyColsBuffer,
        constraintsBuffer,
        prevConstraintsBuffer,
        rebuildParamsBuffer,
        warmstartBuffer,
        solverStateBuffer,
        jointsBuffer: joints.buffer,
        jointSlot: joints,
        paramsBuffer,
        indirectBuffer,
        csrCountsBuffer,
        csrPrefixSum,
        unpackTransformBuffer,
        sizesBuffer,
        shapesBuffer,
        bodyPropsBuffer,
        eidsBuffer,
        packParamsBuffer,
        solverBindGroup,
        narrowBindGroup,
        rebuildBindGroup,
        packBindGroup,
        hullDataBuffer,
        hullIdsBuffer,
        forceBuffer,
        paramsData,
        paramsView: new DataView(paramsData),
        physicsActive: false,
        params: { ...DEFAULT_PARAMS },
        bodyEids: [],
        jointCount: 0,
        jointsNeedUpload: false,
        pendingChanges: new Int32Array(1024),
        pendingChangeCount: 0,
        cachedCapacity: capacity(),
        profile,
        debugReadbackData: new Uint32Array(COUNTERS_SIZE / 4),
        transformReadbackData: new Float32Array(0),
        contactScratch: new Uint32Array(MAX_CONTACTS * CONTACT_STRIDE),
        contactScratchCount: 0,
        contactScratchOverflow: 0,
        readbackStaging: device.createBuffer({
            label: "physics-readback-staging",
            size: COUNTERS_SIZE + capacity() * COMPACT_BYTES + CONTACTS_BYTES,
            usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
        }),
        readbackPending: false,
        readbackReady: false,
        readbackTick: 0,
        readbackGeneration: 0,
        readbackBodyCount: 0,
        lastSyncTick: -1,
        bodyGeneration: 0,
        characterSweepPipeline,
        characterApplyPipeline,
        characterSweepBindGroup,
        characterBuffer,
        characterIndicesBuffer,
        characterParamsBuffer,
        characterGroundBuffer,
        characterCount: 0,
        characters: [],
        characterVerticalVelocity: new Map(),
        characterCoyoteTimers: new Map(),
        characterReadbackStaging,
        characterReadbackPending: false,
    };
}
