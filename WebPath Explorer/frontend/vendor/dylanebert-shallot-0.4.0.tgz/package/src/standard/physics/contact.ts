// GPU contact readback: decode the flat u32 contact buffer into Contact objects.
import { resource } from "../../engine";

export interface Contact {
    bodyA: number;
    bodyB: number;
    posX: number;
    posY: number;
    posZ: number;
    normalX: number;
    normalY: number;
    normalZ: number;
    impulse: number;
}

/** double-buffered contact queue; contacts live 2 physics ticks before being dropped */
export interface Contacts {
    prevData: Uint32Array;
    prevCount: number;
    prevOverflow: number;
    prevTick: number;
    currentData: Uint32Array;
    currentCount: number;
    currentOverflow: number;
    currentTick: number;
}

export interface ContactReader {
    lastTick: number;
}

/** create a fresh cursor; pass to readContacts to iterate new contacts since last read */
export function contactReader(): ContactReader {
    return { lastTick: -1 };
}

const contactBits = new ArrayBuffer(4);
const contactU32 = new Uint32Array(contactBits);
const contactI32 = new Int32Array(contactBits);
const contactF32 = new Float32Array(contactBits);

const contactScratchObj: Contact = {
    bodyA: 0,
    bodyB: 0,
    posX: 0,
    posY: 0,
    posZ: 0,
    normalX: 0,
    normalY: 0,
    normalZ: 0,
    impulse: 0,
};

function decodeContact(data: Uint32Array, i: number, out: Contact): Contact {
    const base = i * 9;
    out.bodyA = data[base];
    contactU32[0] = data[base + 1];
    out.bodyB = contactI32[0];
    contactU32[0] = data[base + 2];
    out.posX = contactF32[0];
    contactU32[0] = data[base + 3];
    out.posY = contactF32[0];
    contactU32[0] = data[base + 4];
    out.posZ = contactF32[0];
    contactU32[0] = data[base + 5];
    out.normalX = contactF32[0];
    contactU32[0] = data[base + 6];
    out.normalY = contactF32[0];
    contactU32[0] = data[base + 7];
    out.normalZ = contactF32[0];
    contactU32[0] = data[base + 8];
    out.impulse = contactF32[0];
    return out;
}

/**
 * iterate contacts newer than reader's cursor; callback value is valid only during the call.
 * contacts older than 2 physics ticks are dropped — read every frame to avoid misses.
 */
export function readContacts(
    contacts: Contacts,
    reader: ContactReader,
    cb: (contact: Contact) => void,
): void {
    if (contacts.prevTick > reader.lastTick) {
        for (let i = 0; i < contacts.prevCount; i++)
            cb(decodeContact(contacts.prevData, i, contactScratchObj));
    }
    if (contacts.currentTick > reader.lastTick) {
        for (let i = 0; i < contacts.currentCount; i++)
            cb(decodeContact(contacts.currentData, i, contactScratchObj));
    }
    reader.lastTick = contacts.currentTick;
}

/** double-buffered contact queue resource; persists 2 physics ticks */
export const Contacts = resource<Contacts>("contacts");
