// ECS component schema for the physics plugin. Pure data — no GPU.
import { traits, buf } from "../../engine";
import { createFieldProxy } from "../../engine/ecs/core";
import { Part } from "../render";

/** backing store for Body's per-entity props; bulk-uploaded to the GPU each frame */
export const BodyData = buf(Float32Array, 4, 0);

export const Body = {
    mass: createFieldProxy(BodyData, 4, 0),
    friction: createFieldProxy(BodyData, 4, 1),
    gravity: createFieldProxy(BodyData, 4, 2),
    group: createFieldProxy(BodyData, 4, 3),
};

traits(Body, {
    requires: [Part],
    defaults: () => ({ mass: 1, friction: 0.5, gravity: 1, group: 0 }),
});

const ForceData = buf(Float32Array, 6, 0);

export const Force = {
    forceX: createFieldProxy(ForceData, 6, 0),
    forceY: createFieldProxy(ForceData, 6, 1),
    forceZ: createFieldProxy(ForceData, 6, 2),
    torqueX: createFieldProxy(ForceData, 6, 3),
    torqueY: createFieldProxy(ForceData, 6, 4),
    torqueZ: createFieldProxy(ForceData, 6, 5),
};

traits(Force, {
    requires: [Body],
    defaults: () => ({ forceX: 0, forceY: 0, forceZ: 0, torqueX: 0, torqueY: 0, torqueZ: 0 }),
});

const ImpulseData = buf(Float32Array, 6, 0);

export const Impulse = {
    impulseX: createFieldProxy(ImpulseData, 6, 0),
    impulseY: createFieldProxy(ImpulseData, 6, 1),
    impulseZ: createFieldProxy(ImpulseData, 6, 2),
    angularImpulseX: createFieldProxy(ImpulseData, 6, 3),
    angularImpulseY: createFieldProxy(ImpulseData, 6, 4),
    angularImpulseZ: createFieldProxy(ImpulseData, 6, 5),
};

traits(Impulse, {
    requires: [Body],
    defaults: () => ({
        impulseX: 0,
        impulseY: 0,
        impulseZ: 0,
        angularImpulseX: 0,
        angularImpulseY: 0,
        angularImpulseZ: 0,
    }),
});

const VelocityData = buf(Float32Array, 6, 0);

export const Velocity = {
    linearX: createFieldProxy(VelocityData, 6, 0),
    linearY: createFieldProxy(VelocityData, 6, 1),
    linearZ: createFieldProxy(VelocityData, 6, 2),
    angularX: createFieldProxy(VelocityData, 6, 3),
    angularY: createFieldProxy(VelocityData, 6, 4),
    angularZ: createFieldProxy(VelocityData, 6, 5),
};

traits(Velocity, {
    requires: [Body],
    defaults: () => ({ linearX: 0, linearY: 0, linearZ: 0, angularX: 0, angularY: 0, angularZ: 0 }),
});

export const BallJoint = {
    bodyA: [] as number[],
    bodyB: [] as number[],
    anchorAX: [] as number[],
    anchorAY: [] as number[],
    anchorAZ: [] as number[],
    anchorBX: [] as number[],
    anchorBY: [] as number[],
    anchorBZ: [] as number[],
    stiffness: [] as number[],
    fracture: [] as number[],
};

traits(BallJoint, {
    defaults: () => ({
        anchorAX: 0,
        anchorAY: 0,
        anchorAZ: 0,
        anchorBX: 0,
        anchorBY: 0,
        anchorBZ: 0,
        stiffness: 0,
        fracture: 0,
    }),
});

export const SpringJoint = {
    bodyA: [] as number[],
    bodyB: [] as number[],
    anchorAX: [] as number[],
    anchorAY: [] as number[],
    anchorAZ: [] as number[],
    anchorBX: [] as number[],
    anchorBY: [] as number[],
    anchorBZ: [] as number[],
    restLength: [] as number[],
    stiffness: [] as number[],
    fracture: [] as number[],
};

traits(SpringJoint, {
    defaults: () => ({
        anchorAX: 0,
        anchorAY: 0,
        anchorAZ: 0,
        anchorBX: 0,
        anchorBY: 0,
        anchorBZ: 0,
        restLength: 0,
        stiffness: 0,
        fracture: 0,
    }),
});

const CharacterData = buf(Float32Array, 4, 0);

export const Character = {
    speed: createFieldProxy(CharacterData, 4, 0),
    maxSlope: createFieldProxy(CharacterData, 4, 1),
    jumpHeight: createFieldProxy(CharacterData, 4, 2),
    grounded: createFieldProxy(CharacterData, 4, 3),
    mass: [] as number[],
    gravity: [] as number[],
    coyoteTime: [] as number[],
    moveX: [] as number[],
    moveZ: [] as number[],
    jump: [] as number[],
};

traits(Character, {
    requires: [Body],
    defaults: () => ({
        speed: 6,
        maxSlope: 0.7,
        jumpHeight: 2.5,
        grounded: 0,
        mass: 70,
        gravity: 50,
        coyoteTime: 0.1,
        moveX: 0,
        moveZ: 0,
        jump: 0,
    }),
});

/** marks a kinematic body as a moving platform — its displacement imparts velocity to contacts */
export const Move = {};
traits(Move, { requires: [Body] });
