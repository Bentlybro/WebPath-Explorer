import { COLOR_FORMAT } from "./scene";

/** linear-filtering sampler — the default for post-process effects sampling the framebuffer */
export function linearSampler(device: GPUDevice): GPUSampler {
    return device.createSampler({ magFilter: "linear", minFilter: "linear" });
}

/**
 * a screen-sized intermediate texture that reallocates when the viewport resizes.
 * Post-process compute nodes write their result here, then publish it via
 * `ctx.setTextureView("color", target.view)`.
 *
 * `ensure()` returns `true` the frame it (re)allocates — callers use that to
 * invalidate cached bind groups that referenced the old view.
 */
export class FullscreenTarget {
    texture: GPUTexture | null = null;
    view: GPUTextureView | null = null;
    private w = 0;
    private h = 0;

    constructor(
        private readonly label: string,
        private readonly format: GPUTextureFormat = COLOR_FORMAT,
    ) {}

    /** (re)allocate to `width`×`height`; returns true if a new texture was created this call */
    ensure(device: GPUDevice, width: number, height: number): boolean {
        if (this.texture && width === this.w && height === this.h) return false;
        this.texture?.destroy();
        this.texture = device.createTexture({
            label: this.label,
            size: { width, height },
            format: this.format,
            usage:
                GPUTextureUsage.STORAGE_BINDING |
                GPUTextureUsage.TEXTURE_BINDING |
                GPUTextureUsage.RENDER_ATTACHMENT,
        });
        this.view = this.texture.createView();
        this.w = width;
        this.h = height;
        return true;
    }

    destroy(): void {
        this.texture?.destroy();
        this.texture = null;
        this.view = null;
        this.w = 0;
        this.h = 0;
    }
}
