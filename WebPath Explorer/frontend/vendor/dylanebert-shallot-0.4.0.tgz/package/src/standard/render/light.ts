import { traits, type State } from "../../engine";
import { formatHex } from "../../engine/ecs/core";
import { Transform, WorldTransform } from "../transforms";
import { unpackColor, normalizeDirection } from "../../engine";

export const AmbientLight = {
    color: [] as number[],
    intensity: [] as number[],
};

traits(AmbientLight, {
    defaults: () => ({ color: 0xffffff, intensity: 0.5 }),
    format: { color: formatHex },
});

export const PointLight = {
    color: [] as number[],
    intensity: [] as number[],
    radius: [] as number[],
    shadows: [] as number[],
};

traits(PointLight, {
    requires: [Transform],
    defaults: () => ({ color: 0xffffff, intensity: 1.0, radius: 10, shadows: 0 }),
    format: { color: formatHex },
});

// A cone light. Beam points down the entity's local -Y axis (so rotating the
// entity aims the beam), matching the conventional spotlight orientation.
// angle is the outer cone half-angle (radians); penumbra (0..1) softens the
// edge — the inner full-intensity cone is angle * (1 - penumbra).
export const SpotLight = {
    color: [] as number[],
    intensity: [] as number[],
    radius: [] as number[],
    angle: [] as number[],
    penumbra: [] as number[],
    shadows: [] as number[],
};

traits(SpotLight, {
    requires: [Transform],
    defaults: () => ({
        color: 0xffffff,
        intensity: 1.0,
        radius: 10,
        angle: Math.PI / 5,
        penumbra: 0.35,
        shadows: 0,
    }),
    format: { color: formatHex },
});

export const DirectionalLight = {
    color: [] as number[],
    intensity: [] as number[],
    directionX: [] as number[],
    directionY: [] as number[],
    directionZ: [] as number[],
    shadows: [] as number[],
};

traits(DirectionalLight, {
    defaults: () => ({
        color: 0xffffff,
        intensity: 1.5,
        directionX: -0.6,
        directionY: -1.0,
        directionZ: -0.8,
        shadows: 1,
    }),
    format: { color: formatHex },
});

interface AmbientLightData {
    color: number;
    intensity: number;
}

interface DirectionalLightData {
    color: number;
    intensity: number;
    directionX: number;
    directionY: number;
    directionZ: number;
}

const lightData = new Float32Array(12);

export function packLightUniforms(
    ambient: AmbientLightData,
    directional: DirectionalLightData,
): Float32Array {
    const ambientRgb = unpackColor(ambient.color);
    lightData[0] = ambientRgb.r;
    lightData[1] = ambientRgb.g;
    lightData[2] = ambientRgb.b;
    lightData[3] = ambient.intensity;

    const [dx, dy, dz] = normalizeDirection(
        directional.directionX,
        directional.directionY,
        directional.directionZ,
    );
    lightData[4] = dx;
    lightData[5] = dy;
    lightData[6] = dz;
    lightData[7] = 0;

    const sunRgb = unpackColor(directional.color);
    lightData[8] = sunRgb.r * directional.intensity;
    lightData[9] = sunRgb.g * directional.intensity;
    lightData[10] = sunRgb.b * directional.intensity;
    lightData[11] = 0;

    return lightData;
}

export const MAX_RASTER_POINT_LIGHTS = 64;
// 16 floats / light: position+radius, color+shadowIdx, spotDir+cosOuter,
// cosInner+3 pad — see POINT_LIGHT_STRUCT_WGSL.
export const POINT_LIGHT_STRIDE = 16;
export const POINT_LIGHT_BUFFER_SIZE = MAX_RASTER_POINT_LIGHTS * POINT_LIGHT_STRIDE * 4;

const pointLightScratch = new Float32Array(MAX_RASTER_POINT_LIGHTS * POINT_LIGHT_STRIDE);

// Packs PointLight and SpotLight entities into one buffer (spots reuse the
// point-light clustering). Point lights write a zero spotDir → no cone.
export function packPointLights(state: State, cameraShadows: boolean): [Float32Array, number] {
    let count = 0;
    let shadowCount = 0;
    let overflow = false;
    const world = WorldTransform.data;

    for (const eid of state.query([PointLight])) {
        if (count >= MAX_RASTER_POINT_LIGHTS) {
            overflow = true;
            break;
        }
        const o = count * POINT_LIGHT_STRIDE;
        pointLightScratch[o] = world[eid * 16 + 12];
        pointLightScratch[o + 1] = world[eid * 16 + 13];
        pointLightScratch[o + 2] = world[eid * 16 + 14];
        pointLightScratch[o + 3] = PointLight.radius[eid];
        const rgb = unpackColor(PointLight.color[eid]);
        const intensity = PointLight.intensity[eid];
        pointLightScratch[o + 4] = rgb.r * intensity;
        pointLightScratch[o + 5] = rgb.g * intensity;
        pointLightScratch[o + 6] = rgb.b * intensity;
        if (cameraShadows && PointLight.shadows[eid] !== 0) {
            pointLightScratch[o + 7] = shadowCount;
            shadowCount++;
        } else {
            pointLightScratch[o + 7] = -1;
        }
        pointLightScratch[o + 8] = 0; // spotDir = 0 → no cone
        pointLightScratch[o + 9] = 0;
        pointLightScratch[o + 10] = 0;
        count++;
    }

    for (const eid of state.query([SpotLight])) {
        if (count >= MAX_RASTER_POINT_LIGHTS) {
            overflow = true;
            break;
        }
        const o = count * POINT_LIGHT_STRIDE;
        pointLightScratch[o] = world[eid * 16 + 12];
        pointLightScratch[o + 1] = world[eid * 16 + 13];
        pointLightScratch[o + 2] = world[eid * 16 + 14];
        pointLightScratch[o + 3] = SpotLight.radius[eid];
        const rgb = unpackColor(SpotLight.color[eid]);
        const intensity = SpotLight.intensity[eid];
        pointLightScratch[o + 4] = rgb.r * intensity;
        pointLightScratch[o + 5] = rgb.g * intensity;
        pointLightScratch[o + 6] = rgb.b * intensity;
        pointLightScratch[o + 7] = -1; // spot shadows not yet supported
        // beam = entity's local -Y axis in world space (normalized)
        let dx = -world[eid * 16 + 4];
        let dy = -world[eid * 16 + 5];
        let dz = -world[eid * 16 + 6];
        const len = Math.hypot(dx, dy, dz) || 1;
        dx /= len;
        dy /= len;
        dz /= len;
        pointLightScratch[o + 8] = dx;
        pointLightScratch[o + 9] = dy;
        pointLightScratch[o + 10] = dz;
        const angle = SpotLight.angle[eid];
        const penumbra = SpotLight.penumbra[eid];
        pointLightScratch[o + 11] = Math.cos(angle); // cosOuter
        pointLightScratch[o + 12] = Math.cos(angle * (1 - penumbra)); // cosInner
        count++;
    }

    if (overflow) console.warn(`raster light cap reached (${MAX_RASTER_POINT_LIGHTS})`);
    return [pointLightScratch, count];
}
