/**
 * builder for the engine's standard render pipelines: `auto` layout, `vs`/`fs`
 * entry points, `triangle-list` topology. Collapses the repeated descriptor
 * boilerplate in forward/shadow/present/overlay to a single call.
 *
 * Pass `code` to compile a fresh shader module, or `module` to reuse one across
 * several pipelines (e.g. depth-inject + depth-only share a module). Every call
 * must supply a `label` — it surfaces in the stats overlay and bench output.
 */
export interface RenderPipelineOptions {
    label: string;
    /** WGSL source; compiled into a module. Ignored if `module` is given. */
    code?: string;
    /** prebuilt module to reuse across pipelines. Takes precedence over `code`. */
    module?: GPUShaderModule;
    targets: GPUColorTargetState[];
    /** vertex entry point, default `"vs"` */
    vertexEntry?: string;
    /** fragment entry point, default `"fs"` */
    fragmentEntry?: string;
    depthStencil?: GPUDepthStencilState;
    /** omit for the WebGPU default (`"none"`) */
    cullMode?: GPUCullMode;
    /** default `"triangle-list"` */
    topology?: GPUPrimitiveTopology;
}

export function renderPipeline(
    device: GPUDevice,
    opts: RenderPipelineOptions,
): Promise<GPURenderPipeline> {
    const module = opts.module ?? device.createShaderModule({ code: opts.code! });
    return device.createRenderPipelineAsync({
        label: opts.label,
        layout: "auto",
        vertex: { module, entryPoint: opts.vertexEntry ?? "vs" },
        fragment: { module, entryPoint: opts.fragmentEntry ?? "fs", targets: opts.targets },
        ...(opts.depthStencil && { depthStencil: opts.depthStencil }),
        primitive: {
            topology: opts.topology ?? "triangle-list",
            ...(opts.cullMode && { cullMode: opts.cullMode }),
        },
    });
}
