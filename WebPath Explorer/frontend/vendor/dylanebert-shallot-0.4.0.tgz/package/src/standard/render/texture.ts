// Albedo texture registry.
//
// Maintains a single `texture_2d_array` (rgba8unorm-srgb) of fixed per-layer
// dimensions. `texture(source)` returns a LAYER INDEX. Layer 0 is reserved as
// 1x1-scaled WHITE so index 0 means "no texture" (sampling it multiplies by 1).
//
// Capacity grows by recreating the array and copyTextureToTexture-ing the old
// layers across (mirrors the gbuf/Registry growth pattern). Consumers (the
// forward pass) watch `textureVersion()` to know when to rebind: the version
// bumps on every registration AND whenever the underlying GPUTexture object is
// replaced (grow), so a changed version always means "rebind the bind group".

export type TextureSource =
    | ImageBitmap
    | HTMLImageElement
    | HTMLCanvasElement
    | OffscreenCanvas
    | HTMLVideoElement;

const LAYER_SIZE = 1024;
const TEXTURE_FORMAT: GPUTextureFormat = "rgba8unorm-srgb";
const INITIAL_LAYERS = 4;

interface PendingUpload {
    layer: number;
    source: TextureSource;
}

let device: GPUDevice | null = null;
let arrayTexture: GPUTexture | null = null;
let arrayView: GPUTextureView | null = null;
let sampler: GPUSampler | null = null;
let capacity = 0;
let count = 0;
let version = 0;

// Sources are retained so a grow (which recreates the texture) can re-upload
// every layer into the new texture via the canvas-resize path. copyTexture is
// also used for already-resident layers, but keeping sources makes the grow
// path simple and robust across capacity changes.
const sources: (TextureSource | null)[] = [];
const pending: PendingUpload[] = [];
const names = new Map<string, number>();

function sourceWidth(source: TextureSource): number {
    return (
        (source as HTMLVideoElement).videoWidth ||
        (source as HTMLImageElement).naturalWidth ||
        (source as ImageBitmap).width
    );
}

function sourceHeight(source: TextureSource): number {
    return (
        (source as HTMLVideoElement).videoHeight ||
        (source as HTMLImageElement).naturalHeight ||
        (source as ImageBitmap).height
    );
}

let resizeCanvas: HTMLCanvasElement | OffscreenCanvas | null = null;

function getResizeCanvas(): HTMLCanvasElement | OffscreenCanvas {
    if (!resizeCanvas) {
        if (typeof OffscreenCanvas !== "undefined") {
            resizeCanvas = new OffscreenCanvas(LAYER_SIZE, LAYER_SIZE);
        } else {
            const c = document.createElement("canvas");
            c.width = LAYER_SIZE;
            c.height = LAYER_SIZE;
            resizeCanvas = c;
        }
    }
    return resizeCanvas;
}

// Returns a source sized exactly LAYER_SIZE x LAYER_SIZE. If the input already
// matches, it is returned as-is; otherwise it is drawn into the scratch canvas.
function fitToLayer(source: TextureSource): TextureSource {
    if (sourceWidth(source) === LAYER_SIZE && sourceHeight(source) === LAYER_SIZE) {
        return source;
    }
    const canvas = getResizeCanvas();
    const ctx = canvas.getContext("2d") as
        | CanvasRenderingContext2D
        | OffscreenCanvasRenderingContext2D
        | null;
    if (!ctx) return source;
    ctx.clearRect(0, 0, LAYER_SIZE, LAYER_SIZE);
    ctx.drawImage(source as CanvasImageSource, 0, 0, LAYER_SIZE, LAYER_SIZE);
    return canvas;
}

function createArray(layers: number): GPUTexture {
    return device!.createTexture({
        label: "albedo-texture-array",
        size: { width: LAYER_SIZE, height: LAYER_SIZE, depthOrArrayLayers: layers },
        format: TEXTURE_FORMAT,
        usage:
            GPUTextureUsage.TEXTURE_BINDING |
            GPUTextureUsage.COPY_DST |
            GPUTextureUsage.COPY_SRC |
            GPUTextureUsage.RENDER_ATTACHMENT,
    });
}

// Writes the reserved white layer 0 by uploading a 1x1 white pixel scaled to
// the full layer (copyExternalImageToTexture handles the scale via canvas).
function uploadWhiteLayer(): void {
    const canvas = getResizeCanvas();
    const ctx = canvas.getContext("2d") as
        | CanvasRenderingContext2D
        | OffscreenCanvasRenderingContext2D
        | null;
    if (!ctx) return;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, LAYER_SIZE, LAYER_SIZE);
    device!.queue.copyExternalImageToTexture(
        { source: canvas as GPUCopyExternalImageSource },
        { texture: arrayTexture!, origin: { x: 0, y: 0, z: 0 } },
        { width: LAYER_SIZE, height: LAYER_SIZE },
    );
}

function uploadLayer(layer: number, source: TextureSource): void {
    const fitted = fitToLayer(source);
    // flipY matches the dominant image convention (three.js TextureLoader,
    // <img>, ImageBitmap drawn top-down): source row 0 is the top of the image,
    // but WGSL samples v=0 at the top of the layer, so without flipY the image
    // renders upside-down. Flip on upload so UV (0,0) is the image's top-left.
    device!.queue.copyExternalImageToTexture(
        { source: fitted as GPUCopyExternalImageSource, flipY: true },
        { texture: arrayTexture!, origin: { x: 0, y: 0, z: layer } },
        { width: LAYER_SIZE, height: LAYER_SIZE },
    );
}

// Ensures the array exists with at least `needed` layers. Grows by recreating
// and copying existing layers across, then re-uploads layer 0 (white). On a
// brand-new array, also re-uploads every retained source.
function ensureCapacity(needed: number): void {
    if (!device) return;

    if (arrayTexture && capacity >= needed) return;

    let newCapacity = capacity === 0 ? INITIAL_LAYERS : capacity;
    while (newCapacity < needed) newCapacity *= 2;

    const old = arrayTexture;
    const oldCapacity = capacity;
    arrayTexture = createArray(newCapacity);
    arrayView = arrayTexture.createView({ dimension: "2d-array" });
    capacity = newCapacity;
    version++;

    if (old) {
        const encoder = device.createCommandEncoder({ label: "albedo-array-grow" });
        encoder.copyTextureToTexture(
            { texture: old },
            { texture: arrayTexture },
            { width: LAYER_SIZE, height: LAYER_SIZE, depthOrArrayLayers: oldCapacity },
        );
        device.queue.submit([encoder.finish()]);
        old.destroy();
    } else {
        // Fresh array: write white into layer 0.
        uploadWhiteLayer();
    }
}

function flushPending(): void {
    if (!device || pending.length === 0) return;
    ensureCapacity(count);
    for (const p of pending) uploadLayer(p.layer, p.source);
    pending.length = 0;
}

function ensureSampler(): GPUSampler {
    if (!sampler) {
        sampler = device!.createSampler({
            label: "albedo-sampler",
            magFilter: "linear",
            minFilter: "linear",
            mipmapFilter: "linear",
            addressModeU: "repeat",
            addressModeV: "repeat",
        });
    }
    return sampler;
}

// Called by the render plugin once the GPU device exists. Initializes the array
// (reserving white layer 0) and flushes any uploads queued before the device
// was ready.
export function setTextureDevice(d: GPUDevice): void {
    if (device === d) {
        flushPending();
        return;
    }
    device = d;
    // Reset GPU-side state for the new device; logical registrations persist.
    arrayTexture = null;
    arrayView = null;
    sampler = null;
    capacity = 0;
    ensureSampler();

    // Reserve layer 0 (white) and re-upload any logically-registered sources.
    ensureCapacity(Math.max(count, 1));
    for (let layer = 1; layer < count; layer++) {
        const src = sources[layer];
        if (src) uploadLayer(layer, src);
    }
    flushPending();
}

// Registers a texture and returns its LAYER INDEX. Index 0 is reserved white.
// If the device is not ready yet, the upload is deferred until setTextureDevice.
export function texture(source: TextureSource, name?: string): number {
    if (name !== undefined) {
        const existing = names.get(name);
        if (existing !== undefined) {
            sources[existing] = source;
            if (device) {
                ensureCapacity(count);
                uploadLayer(existing, source);
            } else {
                pending.push({ layer: existing, source });
            }
            version++;
            return existing;
        }
    }

    if (count === 0) {
        // Reserve layer 0 as white the first time anything registers.
        count = 1;
        sources[0] = null;
    }

    const layer = count++;
    sources[layer] = source;
    if (name !== undefined) names.set(name, layer);

    if (device) {
        ensureCapacity(count);
        uploadLayer(layer, source);
    } else {
        pending.push({ layer, source });
    }
    version++;
    return layer;
}

// A valid array view is required even when no textures are registered (the bind
// group always binds slot 11/12). Lazily creates a 1-layer white array so the
// forward pass can bind unconditionally.
export function getTextureArrayView(): GPUTextureView {
    if (!arrayView) {
        if (!device) {
            throw new Error("[texture] device not ready; call setTextureDevice first");
        }
        ensureCapacity(1);
    }
    flushPending();
    return arrayView!;
}

export function getSampler(): GPUSampler {
    return ensureSampler();
}

export function textureVersion(): number {
    return version;
}

// Re-uploads a frame into an already-registered layer. For dynamic textures —
// video, canvas, webcam — call this each frame with the live source. No version
// bump: the layer index is unchanged, so no rebind is needed.
export function updateTexture(layer: number, source: TextureSource): void {
    if (!device || !arrayTexture || layer < 1 || layer >= capacity) return;
    if (sourceWidth(source) === 0 || sourceHeight(source) === 0) return; // not ready
    uploadLayer(layer, source);
}

export function clearTextures(): void {
    if (arrayTexture) arrayTexture.destroy();
    arrayTexture = null;
    arrayView = null;
    capacity = 0;
    count = 0;
    sources.length = 0;
    pending.length = 0;
    names.clear();
    version++;
}
