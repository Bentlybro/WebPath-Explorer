/* @ts-self-types="./shallot_transforms.d.ts" */

/**
 * @param {number} count
 */
export function compute_transforms(count) {
    wasm.compute_transforms(count);
}

/**
 * @param {number} n
 */
export function ensure_capacity(n) {
    wasm.ensure_capacity(n);
}

/**
 * @returns {number}
 */
export function get_capacity() {
    const ret = wasm.get_capacity();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_indices_ptr() {
    const ret = wasm.get_indices_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_matrices_ptr() {
    const ret = wasm.get_matrices_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_max_entities() {
    const ret = wasm.get_max_entities();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_no_parent() {
    const ret = wasm.get_no_parent();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_parents_ptr() {
    const ret = wasm.get_parents_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_pos_x_ptr() {
    const ret = wasm.get_pos_x_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_pos_y_ptr() {
    const ret = wasm.get_pos_y_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_pos_z_ptr() {
    const ret = wasm.get_pos_z_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_quat_w_ptr() {
    const ret = wasm.get_quat_w_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_quat_x_ptr() {
    const ret = wasm.get_quat_x_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_quat_y_ptr() {
    const ret = wasm.get_quat_y_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_quat_z_ptr() {
    const ret = wasm.get_quat_z_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_scale_x_ptr() {
    const ret = wasm.get_scale_x_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_scale_y_ptr() {
    const ret = wasm.get_scale_y_ptr();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function get_scale_z_ptr() {
    const ret = wasm.get_scale_z_ptr();
    return ret >>> 0;
}

export function init_data() {
    wasm.init_data();
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
    };
    return {
        __proto__: null,
        "./shallot_transforms_bg.js": import0,
    };
}

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('shallot_transforms_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
